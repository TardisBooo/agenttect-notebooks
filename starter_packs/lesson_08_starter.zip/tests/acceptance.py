import argparse
import json
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument("--artifact", required=True)
a = p.parse_args()
r = json.loads((Path(a.artifact) / "receipt.json").read_text(encoding="utf-8"))
assert r["schema"] == "lab-receipt/v1"
assert r["execution_type"] == "offline_synthetic"
assert r["usage"]["input_tokens"] is None
assert r["unexecuted"]["real_model"] == "UNEXECUTED"
root = Path(a.artifact)
experiment = r["experiment"]
if experiment == "main08":
    comparison = json.loads((root / "comparison.json").read_text(encoding="utf-8"))
    assert set(comparison) == {"single", "fixed", "dynamic"}
    assert [len(comparison[m]["facts"]) for m in ("single", "fixed", "dynamic")] == [4, 3, 4]
    assert all(o["status"] == "partial" for o in comparison.values())
elif experiment == "main11":
    result = json.loads((root / "evaluation.json").read_text(encoding="utf-8"))
    assert result["counts"]["planned"] == result["counts"]["launched"]
    assert result["counts"]["passed"] == result["counts"]["planned"]
    assert result["denominators"]["eligible_repeat_outcomes"] == result["counts"]["planned"]
    assert result["denominators"]["excluded_repeat_outcomes"] == 0
    for group in result["per_task"].values():
        assert group["eligible"] == group["k"]
        assert group["excluded"] == 0
        assert group["observed_pass_at_k"] is True
        assert group["observed_pass_power_k"] is True
elif experiment == "lm4":
    rows = [json.loads(line) for line in (root / "dataset.jsonl").read_text().splitlines()]
    assert len(rows) == 2
    assert all(row["loss_mask"] == [0, 0, 1, 1, 0, 0, 1] for row in rows)
elif experiment == "lm5":
    result = json.loads((root / "signals.json").read_text(encoding="utf-8"))
    assert len(result["samples"]) == 3
    assert all(s["reverse_kl_student_teacher"]["state"] == "finite" for s in result["samples"])
elif experiment == "lm6":
    result = json.loads((root / "audit.json").read_text(encoding="utf-8"))
    assert any(c["reward_exploit"] for g in result["groups"] for c in g["candidates"])
elif experiment == "sys6":
    replay = json.loads((root / "replay.json").read_text(encoding="utf-8"))
    assert [o["version"] for o in replay] == [0, 1, 2, 3]
    assert replay[-1]["terminated"] and replay[-1]["reward"] == "1"
print("PUBLIC_RECEIPT_PASS")
