# Experiment evidence

Experiment ID:
Python version:
Input SHA-256 values:
Exact commands:
Output directory:
Observed checks and failures:
Actual usage and denominators:
Architecture decision supported by those results:
Unexecuted model, GPU and upstream environment work:

Do not replace observations with expected results. Do not include credentials or personal data.
