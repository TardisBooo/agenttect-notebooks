# 离线操作示例

先运行 `python -m research_eval_lab --help`。学生初始代码的实际预期是 NOT_IMPLEMENTED 和退出 2。以下是实现后的公开验收目标，不是初始代码已经完成的结果。输出必须是新目录。

## main08

`main08 --task fixtures/research/task.json --corpus fixtures/research/corpus.json --modes single,fixed,dynamic --adapter fixture --output run08`。single/dynamic 得到 4 项事实和 cash 缺口，fixed 初次检索得到 3 项事实。FY2024/FY2023 的毛利率分别 0.4500/0.4000，收入变化 20.0000。所有模式为 partial。

4/3/4 来自课程预编的 fixture 策略。默认 fixed worker 只读 initial search，single/dynamic 会按缺项搜索。这不是固定任务图或多 Agent 的能力上限。固定 worker 也能循环用工具；教师的预设补查 probe 会得到 4 项事实。因此本例验证派工、证据和合并机制，不能证明动态架构比固定架构质量更高。查看每个模式的 run.json、worker actions 和任务事件后再解释结果。

## main11

复制 system-template.json，填写绝对 Python 和实现目录。oracle 由教师单独提供。运行 `main11 --suite fixtures/evaluation/suite.json --system YOUR_SYSTEM --oracle TEACHER_ORACLE --repeats 3 --output run11`。正常 reference 的 planned/launched/graded/passed 各为 3。不要把 fixture 的稳定性外推为模型成功率。

## lm4

`lm4 --traces fixtures/sft/traces.jsonl --split fixtures/sft/split.json --output run4`。得到两个样本。每个 tokens 长 7，mask 为 [0,0,1,1,0,0,1]。train/eval 各一组。

## lm5

`lm5 --samples fixtures/distillation/samples.json --output run5`。三个来源各一行 reverse KL 约 0.1046496，保留 provenance。没有权重文件。

## lm6

`lm6 --rollouts fixtures/reward/rollouts.json --output run6`。correct reward=1 且独立通过，exploit reward=3 且独立失败。advantage 约为 -1 与 +1。把 correct.output 改成纯数字 `120` 后，独立检查仍通过，proxy reward 变成 0。再把声明 value 保持为 `120`、output 改为 `999`，独立检查必须失败。

## sys6

`sys6 replay --task fixtures/environment/task.json --actions fixtures/environment/actions.jsonl --output run-env`。reset 后 version=0，search/read/submit 后为 1/2/3。最后 reward=1，terminated=true，truncated=false。另用 reset/step 手工运行并故意提交旧 version。
