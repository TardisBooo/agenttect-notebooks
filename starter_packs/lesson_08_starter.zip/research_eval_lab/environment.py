from .contracts import LabError


class ResearchEnvironment:
    @classmethod
    def create(cls, *, task, episode_dir):
        raise LabError("NOT_IMPLEMENTED", "ResearchEnvironment.create")

    def reset(self):
        raise LabError("NOT_IMPLEMENTED", "ResearchEnvironment.reset")

    def step(self, *, action, expected_version):
        raise LabError("NOT_IMPLEMENTED", "ResearchEnvironment.step")

    def inspect(self):
        raise LabError("NOT_IMPLEMENTED", "ResearchEnvironment.inspect")
