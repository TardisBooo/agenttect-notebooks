from .contracts import LabError


def dispatch(args) -> int:
    raise LabError("NOT_IMPLEMENTED", args.command)
