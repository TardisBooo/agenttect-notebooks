from .contracts import LabError


class ResearchExperiment:
    def __init__(self, adapter):
        self.adapter = adapter

    def run(self, *, task, corpus, mode, run_dir):
        raise LabError("NOT_IMPLEMENTED", "ResearchExperiment.run")
