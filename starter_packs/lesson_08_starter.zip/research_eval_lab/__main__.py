import argparse
import json
import sys
from pathlib import Path

from . import commands
from .contracts import LabError


def parser() -> argparse.ArgumentParser:
    root = argparse.ArgumentParser(prog="research_eval_lab")
    sub = root.add_subparsers(dest="command", required=True)
    specs = {
        "main08": ("task", "corpus", "modes", "adapter", "output"),
        "main11": ("suite", "system", "oracle", "repeats", "output"),
        "lm4": ("traces", "split", "output"),
        "lm5": ("samples", "output"),
        "lm6": ("rollouts", "output"),
        "inspect": ("run",),
        "cancel": ("run", "reason"),
        "grade": ("trial", "oracle", "output"),
        "calibrate": ("cases", "output"),
    }
    for name, options in specs.items():
        command = sub.add_parser(name)
        for option in options:
            command.add_argument(
                "--" + option, required=True, type=int if option == "repeats" else str
            )
    environment = sub.add_parser("sys6").add_subparsers(dest="operation", required=True)
    for operation, options in {
        "replay": ("task", "actions", "output"),
        "reset": ("task", "episode"),
        "step": ("episode", "expected-version", "action"),
    }.items():
        command = environment.add_parser(operation)
        for option in options:
            command.add_argument(
                "--" + option, required=True, type=int if option == "expected-version" else str
            )
    return root


def main() -> int:
    args = parser().parse_args()
    try:
        output = getattr(args, "output", None)
        if output and Path(output).exists():
            raise LabError("OUTPUT_EXISTS", output)
        return commands.dispatch(args)
    except (LabError, OSError, KeyError, TypeError, ValueError) as exc:
        code = exc.code if isinstance(exc, LabError) else "INVALID_INPUT"
        print(json.dumps({"error": code, "detail": str(exc)}), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
