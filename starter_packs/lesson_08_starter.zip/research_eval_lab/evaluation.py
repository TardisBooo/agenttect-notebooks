from .contracts import LabError


class EvaluationHarness:
    def __init__(self, grader):
        self.grader = grader

    def run(self, *, suite, system, repeats, output_dir):
        raise LabError("NOT_IMPLEMENTED", "EvaluationHarness.run")
