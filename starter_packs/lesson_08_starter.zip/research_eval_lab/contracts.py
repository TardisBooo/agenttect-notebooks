import hashlib
import json
import re
from dataclasses import asdict, dataclass
from datetime import datetime
from decimal import Decimal, InvalidOperation
from enum import StrEnum
from pathlib import Path
from typing import Any


class LabError(ValueError):
    def __init__(self, code: str, detail: str = ""):
        self.code = code
        super().__init__(detail or code)


class Mode(StrEnum):
    SINGLE = "single"
    FIXED = "fixed"
    DYNAMIC = "dynamic"


class ResearchStatus(StrEnum):
    COMPLETE = "complete"
    PARTIAL = "partial"
    FAILED = "failed"
    CANCELLED = "cancelled"


class Verdict(StrEnum):
    PASS = "pass"
    FAIL = "fail"
    UNKNOWN = "unknown"
    ERROR = "error"


@dataclass(frozen=True)
class InputVersion:
    task_sha256: str
    corpus_sha256: str
    tools_sha256: str


@dataclass(frozen=True)
class AttemptKey:
    run_id: str
    task_id: str
    generation: int
    attempt: int
    input_version: InputVersion


@dataclass(frozen=True)
class TaskBrief:
    task_id: str
    parent_id: str | None
    goal: str
    fact_keys: tuple[str, ...]
    dependencies: tuple[str, ...]
    context_source_ids: tuple[str, ...]
    allowed_tools: tuple[str, ...]
    input_version: InputVersion
    owner: str
    deadline_utc: str
    max_attempts: int


@dataclass(frozen=True)
class EvidenceRef:
    source_id: str
    source_sha256: str
    published_at: str
    start: int
    end: int
    quote: str


@dataclass(frozen=True)
class Fact:
    key: str
    value: str
    period: str
    unit: str
    basis: str
    evidence: tuple[EvidenceRef, ...]


@dataclass(frozen=True)
class ResearchOutcome:
    schema: str
    attempt: AttemptKey
    status: ResearchStatus
    facts: tuple[Fact, ...]
    explanation: str
    unresolved: tuple[dict[str, Any], ...]
    actions: tuple[dict[str, Any], ...]
    trace_sha256: str
    usage: dict[str, Any]
    stop_reason: str
    derived: dict[str, str]


@dataclass(frozen=True)
class GradeResult:
    verdict: Verdict
    checks: tuple[dict[str, Any], ...]
    grader_version: str
    oracle_version: str


@dataclass(frozen=True)
class ResearchTask:
    task_id: str
    cutoff_utc: str
    required_facts: tuple[dict[str, str], ...]
    allowed_source_ids: tuple[str, ...]
    allowed_tools: tuple[str, ...]
    budget: dict[str, int]
    raw: dict[str, Any]

    @classmethod
    def parse(cls, raw: dict[str, Any]) -> "ResearchTask":
        require(raw.get("schema") == "research-task/v1", "TASK_SCHEMA")
        identifier(raw["task_id"])
        utc(raw["cutoff_utc"])
        facts = tuple(raw["required_facts"])
        require(bool(facts), "EMPTY_FACTS")
        require(len({f["key"] for f in facts}) == len(facts), "DUPLICATE_FACT")
        for fact in facts:
            require(
                all(
                    isinstance(fact.get(k), str) and fact[k]
                    for k in ("key", "period", "unit", "basis")
                ),
                "FACT_SPEC",
            )
        sources = tuple(raw["allowed_source_ids"])
        require(len(set(sources)) == len(sources), "DUPLICATE_SOURCE")
        for source in sources:
            identifier(source)
        tools = tuple(raw["allowed_tools"])
        require(bool(tools) and set(tools) <= {"search", "read"}, "TOOL_PERMISSION")
        limits = raw["budget"]
        for name in (
            "max_calls",
            "max_tasks",
            "max_attempts",
            "max_children",
            "max_depth",
            "deadline_ms",
        ):
            require(type(limits.get(name)) is int and limits[name] > 0, "BUDGET_SPEC", name)
        return cls(raw["task_id"], raw["cutoff_utc"], facts, sources, tools, limits, raw)


@dataclass(frozen=True)
class Source:
    source_id: str
    version: str
    origin: str
    published_at: str
    text: str

    @property
    def sha256(self) -> str:
        return hashlib.sha256(self.text.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class Corpus:
    sources: tuple[Source, ...]
    search_index: dict[str, list[str]]
    raw: dict[str, Any]

    @classmethod
    def parse(cls, raw: dict[str, Any]) -> "Corpus":
        require(raw.get("schema") == "corpus/v1", "CORPUS_SCHEMA")
        sources = tuple(Source(**s) for s in raw["sources"])
        require(len({s.source_id for s in sources}) == len(sources), "DUPLICATE_SOURCE")
        for source in sources:
            identifier(source.source_id)
            utc(source.published_at)
            require(
                bool(source.version) and bool(source.origin) and isinstance(source.text, str),
                "SOURCE_SPEC",
            )
        index = raw["search_index"]
        ids = {s.source_id for s in sources}
        require(
            all(
                isinstance(v, list) and len(v) == len(set(v)) and set(v) <= ids
                for v in index.values()
            ),
            "SEARCH_INDEX",
        )
        return cls(sources, index, raw)


@dataclass(frozen=True)
class SystemSpec:
    argv: tuple[str, ...]
    cwd: str
    environment_allowlist: tuple[str, ...]
    version: str
    timeout_seconds: float

    @classmethod
    def parse(cls, raw: dict[str, Any]) -> "SystemSpec":
        require(raw.get("schema") == "system/v1", "SYSTEM_SCHEMA")
        require(isinstance(raw["argv"], list) and bool(raw["argv"]), "SYSTEM_ARGV")
        require(all(isinstance(a, str) for a in raw["argv"]), "SYSTEM_ARGV")
        require(Path(raw["cwd"]).is_absolute(), "SYSTEM_CWD")
        require(isinstance(raw["environment_allowlist"], list), "SYSTEM_ENV")
        require(
            all(
                isinstance(n, str) and re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", n)
                for n in raw["environment_allowlist"]
            ),
            "SYSTEM_ENV",
        )
        timeout = float(decimal(raw["timeout_seconds"]))
        require(timeout > 0, "SYSTEM_TIMEOUT")
        require(bool(raw["version"]), "SYSTEM_VERSION")
        return cls(
            tuple(raw["argv"]),
            raw["cwd"],
            tuple(raw["environment_allowlist"]),
            raw["version"],
            timeout,
        )


def require(condition: bool, code: str, detail: str = "") -> None:
    if not condition:
        raise LabError(code, detail)


def identifier(value: str) -> str:
    require(
        isinstance(value, str) and bool(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,99}", value)),
        "INVALID_ID",
    )
    return value


def utc(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    require(
        parsed.utcoffset() is not None and parsed.utcoffset().total_seconds() == 0, "UTC_REQUIRED"
    )
    return parsed


def decimal(value: Any) -> Decimal:
    try:
        result = Decimal(str(value))
    except InvalidOperation as exc:
        raise LabError("INVALID_NUMBER") from exc
    require(result.is_finite(), "NONFINITE_NUMBER")
    return result


def encode(value: Any) -> str:
    def default(item: Any) -> Any:
        if hasattr(item, "__dataclass_fields__"):
            return asdict(item)
        if isinstance(item, (Decimal, Path)):
            return str(item)
        raise TypeError(type(item).__name__)

    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, indent=2, default=default, allow_nan=False
    )


def digest(value: Any) -> str:
    return hashlib.sha256(encode(value).encode("utf-8")).hexdigest()


def read_json(path: str | Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def write_json(path: Path, value: Any) -> None:
    path.write_text(encode(value) + "\n", encoding="utf-8")
