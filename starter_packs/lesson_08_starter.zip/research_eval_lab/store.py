from .contracts import LabError


class TreeStore:
    def __init__(self, path):
        raise LabError("NOT_IMPLEMENTED", "TreeStore")
