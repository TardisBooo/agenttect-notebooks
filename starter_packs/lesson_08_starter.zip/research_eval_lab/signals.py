from .contracts import LabError


def prepare_sft(traces, split):
    raise LabError("NOT_IMPLEMENTED", "prepare_sft")


def distillation_signals(samples):
    raise LabError("NOT_IMPLEMENTED", "distillation_signals")


def reward_audit(groups):
    raise LabError("NOT_IMPLEMENTED", "reward_audit")
