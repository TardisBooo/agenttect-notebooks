# 实验契约 v1

本契约固定 main08、main11、LM4、LM5、LM6、SYS6 的公共接口。Python 3.11+，仅用标准库。CLI、字段名和日志用英文。教学说明用中文。以下 schema、任务字段、预算单位和 fixture 策略是课程本地设计。

## 命令与退出码

```text
python -m research_eval_lab main08 --task TASK --corpus CORPUS --modes single,fixed,dynamic --adapter fixture --output NEWDIR
python -m research_eval_lab main11 --suite SUITE --system SYSTEM --oracle ORACLE --repeats 3 --output NEWDIR
python -m research_eval_lab lm4 --traces TRACES --split SPLIT --output NEWDIR
python -m research_eval_lab lm5 --samples SAMPLES --output NEWDIR
python -m research_eval_lab lm6 --rollouts ROLLOUTS --output NEWDIR
python -m research_eval_lab sys6 replay --task TASK --actions ACTIONS --output NEWDIR
python -m research_eval_lab inspect --run RUNDIR
python -m research_eval_lab cancel --run RUNDIR --reason REASON
python -m research_eval_lab grade --trial TRIALDIR --oracle ORACLE --output NEWDIR
python -m research_eval_lab calibrate --cases CASES --output NEWDIR
python -m research_eval_lab sys6 reset --task TASK --episode NEWDIR
python -m research_eval_lab sys6 step --episode DIR --expected-version 0 --action ACTION
```

所有输入都显式指定。`--output` 和首次 `--episode` 必须不存在。已占用返回 `OUTPUT_EXISTS`，不覆盖旧证据。退出 0 表示命令生成有效产物，研究任务可以合法地 partial；退出 1 表示系统执行或验收失败；退出 2 表示输入非法、操作不支持或路径冲突。未实现的学生操作返回 `NOT_IMPLEMENTED` 和 2，`--help` 必须成功。

## main08

`research-task/v1` 含 `task_id`、`cutoff_utc`、`required_facts`、`allowed_source_ids`、`allowed_tools`、`budget`。每个 required fact 含 `key`、`period`、`unit`、`basis`。预算含 `max_calls`、`max_tasks`、`max_attempts`、`max_children`、`max_depth`、`deadline_ms`。工具仅为 search/read。预算计入 parent、worker、verifier、retry 和 synthesis 的 synthetic call units。未知模型 token 和金额为 null。

`corpus/v1` 含唯一 `source_id` 的 sources 和 search_index。search_index 的每个列表只能引用已有 source_id，同一列表内不得重复。Source 含 `source_id`、`version`、`origin`、`published_at`、`text`。`text` 是一行一个 JSON object 的冻结 Unicode 文本，每行含 `key,value,period,unit,basis`；value 为有限十进制字符串。Evidence 的 start/end 是半开 Unicode codepoint 区间，quote 必须等于原文片段，source_sha256 是 text 的 SHA-256。数值、期间、单位和口径都从该片段重新解析，不凭摘要或自报成功。

`InputVersion(task_sha256,corpus_sha256,tools_sha256)` 冻结输入。`AttemptKey(run_id,task_id,generation,attempt,input_version)` 标识一次执行。`TaskBrief` 含父任务、目标、事实范围、依赖、来源上下文、权限、owner、deadline、max_attempts。任务图拒绝循环、缺失依赖、越权、版本漂移和冲突派工。重放同一派工返回原 ticket。

每个模式写 `run.json`、`outcome.json`、`events.jsonl`、`usage.json` 和内部 `state.sqlite3`。`research-outcome/v1` 含 attempt、status、facts、explanation、unresolved、actions、trace_sha256、usage、stop_reason。status 为 complete/partial/failed/cancelled。fact 含 key/value/period/unit/basis/evidence。unresolved 的 reason 含 missing/conflict/deadline/budget/tool_error/invalid_evidence。派生指标用 Decimal 重新计算，四位小数 ROUND_HALF_EVEN。缺证据保留 partial，冲突保留所有候选，不能以最新返回覆盖。

同一 task/corpus/tools 下比较三个模式。single 使用一个循环。fixed 按期间预分配独立 worker。dynamic 在初次搜索缺少某项后，依据具体缺口再派一次补查；资料全集仍缺失的项保留 unresolved。worker 只返回局部结果。store 独占任务图、事件、事务和全树预留/结算。取消推进 generation，禁止新调用，迟到结果记 STALE_RESULT 并结算已消耗工作，不能改变接受结果。

worker 每次 search/read 前检查该次预留的 cap，并先保存调用记录。结算使用实际调用数，不截断到 cap。缺失、损坏、超额或相互矛盾的 worker 用量记录属于完整性错误。此时保留该次 cap，usage.synthetic_calls 为 null，known_synthetic_calls 仅表示已经可靠结算的调用数。reserved_calls 表示尚未结算的预留。父任务、子任务和整个 run 的 deadline 都限制新调用、重试和结果接受。过期结果记 RESULT_REJECTED，reason=DEADLINE，不能发布新事实；截止后仍结算已消耗的工作。正常汇总若跨过 run deadline，则输出 partial/deadline，保留此前已接受的事实。

默认 fixed 的 initial-only 是 fixture 策略的刻意简化。固定 worker 同样可以按预定策略补查。4/3/4 只证明这些预编策略的离线行为，不是架构优劣的测量。run.json 必须记录具体策略，events 与 actions 保留实际任务计划和工具路径。

## main11

`evaluation-suite/v1` 含 `suite_id`、`tasks` 和 `sampling_assumption`。每项含唯一 id、task、corpus 的显式路径，可选 `mode`。相对路径以 suite 所在目录解析。`system/v1` 含 `argv`、`cwd`、`environment_allowlist`、`version`、`timeout_seconds`。argv 是字符串数组，不经过 shell；模板只支持 `{task}`、`{corpus}`、`{output}`、`{trial_id}`。不支持隐式命令拼接。超时终止子进程。

每次 trial 独立子进程和 work 目录，仅复制公共 task/corpus。oracle 单独交给 grader，绝不复制到 work。系统 stdout/stderr、最终 outcome、trace 和 grader 各自保存。`grade` 接收保存 task.json、corpus.json、outcome.json 的 trial 目录。独立 grader 读最终事实和证据，不依赖 status/explanation。oracle 含 schema `research-oracle/v1`、version 和 tasks，按 task_id 指定 expected_values、required_unresolved、expected_status；不能适用时 unknown，评分器异常为 error。

receipt 分开记录 planned、launched、observed、graded、passed、failed、system_failed、timed_out、infrastructure_failed、grader_error、unknown、reruns、unexecuted；保留 launched 和 graded 两个分母。per_task.outcomes 按计划顺序记录 true、false 或 null。系统崩溃、超时、错误退出和独立评分 fail 为 false。未启动、无可用评分、unknown 和 grader error 为 null。每组显式记录 eligible 与 excluded；denominators 汇总 eligible_repeat_outcomes 与 excluded_repeat_outcomes。k 始终是计划重复次数，不随缺失结果缩小。只有 k 次结果都有效时，observed_pass_at_k 才报告至少一次通过，observed_pass_power_k 才报告全部通过；否则两者为 null。这些是保存重复组的观察指标，不是独立同分布的成功概率，model_variability_estimate 保持 null。calibrate 输入 cases 列表，每项有 trial、oracle、expected；独立检查正确解、合法替代、错误和注入文本。

## LM4

JSONL trace 每项含 trace_id、task_id、session_id、near_duplicate_group、tokenizer_id、tokenization_version、messages。message 含 role 和 tokens；role 是 user/assistant/tool，assistant 可含 tool_call_id，tool 必须回同一 call_id。tokens 是非负整数。工具观察只作上下文，assistant token 的 loss_mask 为 1，其余为 0。拒绝未配对工具调用、空监督、坏顺序。split.json 以 trace_id 指定 train/eval；同 task、session 或 near_duplicate_group 不得跨集。输出 dataset.jsonl 和 diagnostics.json，不执行权重训练。

## LM5

samples.json 含 samples。每项含 id、teacher_id、student_id、checkpoint_id、condition_id、kind、sampling_policy、sampling_distribution、teacher、student。后两项是相同词表的概率映射。kind 为 off_policy/on_policy/self_distillation，sampling_policy 分别为 teacher/student/conditioned_teacher，sampling_distribution 必须与所声明来源一致。self_distillation 另含 base_model_id 且 teacher_id/student_id 相同。输出 reverse KL `sum(q*log(q/p))`、teacher_cross_entropy 和 sampling provenance。概率必须有限、非负且归一化。q>0,p=0 输出 explicit infinite，不平滑。不同目标的绝对 loss 不作排名。

## LM6

rollouts.json 含 groups。每组含 group_id、task_id、input_version、policy_version、candidates，每项含 id、同组身份、output、task_check。proxy reward 是 output 中完整 Markdown code block 数，保留原始块数，不因独立检查结果调整 reward。

output 的有效答案格式有两种。第一种是完整的 JSON number 文本，例如 `120` 或 `1.2e2`。第二种是只含一个 JSON number 的单个 json fenced code block。允许首尾空白；不允许额外解释、多个块、JSON object、字符串或非有限数值。task_check.expected_value 是公共任务的预期值；task_check.value 是候选声明值。独立检查从实际 output 解析有限 Decimal，要求解析值、声明值和预期值三者相等。候选不能只填对 value 来掩盖错误输出。population std，epsilon=1e-8，advantage=(reward-mean)/(std+epsilon)。至少两个候选，同组身份必须一致；零方差输出零 advantage 并标记。报告高 reward 但独立检查失败的候选。此处演示 GRPO signal，不更新权重。

## SYS6

environment-task/v1 含 task_id、seed、max_steps、sources 和 target。sources 是 source_id 到文本的映射，target 含 source_id 和 answer。reset 创建一次独立 episode，写 state.sqlite3。step 必须提供 expected_version，action 含 episode_id、kind 和必要字段。kind 为 search/read/submit。search 含 query，read 含 source_id，submit 含 answer。action 不能读取任意路径。每步推进 version，reward 从真实状态计算；正确提交且已读目标才 terminated，资源耗尽则 truncated。terminal 后拒绝动作。reset 在未 step 时幂等；已经开始则 `EPISODE_ALREADY_STARTED`。新回合使用新目录。replay 依次执行 actions，支持 episode_id=`CURRENT`，写 reset 与每步 observation/reward/terminated/truncated/state_sha256。

## 共同 receipt 与边界

`lab-receipt/v1` 记录 experiment、execution_type=`offline_synthetic`、input_hashes、commands、checks、counts、unexecuted 和 actual elapsed。real_model、GPU training、OpenEnv、Harbor、upstream launchers 标为 UNEXECUTED；unmeasured tokens/currency 为 null。digest 检测内容变化，不证明真伪。同用户进程隔离不构成安全沙箱。optional live port 标为 DEFERRED。
