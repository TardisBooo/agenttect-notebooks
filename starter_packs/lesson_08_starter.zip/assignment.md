# 作业要求

## main08

1. 实现三种研究循环，所有模式使用相同输入。
2. 动态补查 gross_profit:FY2024，cash:FY2024 保留缺口。
3. 证明重复派工、预算、证据、超时和取消后迟到结果均受控制。
4. 比较保留或合并协作环节的理由。

## main11

1. 通过 argv 启动完整系统，重复运行并独立评分。
2. 区分系统、超时、基础设施和 grader 故障。
3. 先跑 reference 与 no-op，再校准错误、合法替代、注入和汇总损坏。
4. 分别保留已启动系统次数 launched_system 和有效评分次数 validly_graded 两个分母。

## lm4

1. 转换 trace，生成 assistant loss mask。
2. 验证工具配对与角色顺序。
3. 按 task、session 和 near_duplicate_group 分组切分。
4. 提交实际 dataset 和拒绝泄漏的证据。

## lm5

1. 保留三种采样来源，计算 reverse KL 与交叉熵。
2. 处理零概率和非法概率。
3. 不得把不同 objective 的 loss 排名或声称训练完成。

## lm6

1. 计算 grouped GRPO advantage，说明 population std 和 epsilon。
2. 从完整 output 解析纯数字或单个 JSON 数字代码块，要求解析值同时等于 task_check.value 和 expected_value。
3. 找出高 proxy reward 却独立失败的候选。
4. 补做零方差、混组拒绝、声明值与输出不符的检查。

## sys6

1. 实现隔离 episode 的 reset、step 和 replay。
2. 真实读取后提交答案，奖励由状态计算。
3. 证明 stale version、跨回合、terminal 后操作与步数耗尽的行为。

## 交付

1. 每项交付填写 templates/EVIDENCE.md。
2. 模型、GPU 与上游环境未运行时明确写 UNEXECUTED。
