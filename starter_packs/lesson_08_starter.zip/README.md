# Research evaluation exercises

Use Python 3.11 or newer. No installation or third-party package is required. Run `python -m research_eval_lab --help` from this directory. The starter exposes the complete command surface and deliberately returns JSON error `NOT_IMPLEMENTED` with exit code 2 until you implement an operation.

Read `contract.md`, then your experiment's section in `assignment.md` and `tutorial.md`. Write every command's output to a new directory. Public synthetic inputs are in `fixtures/`; expected public behavior is in `tests/acceptance.py`. There are no reference algorithms, hidden labels, model weights or credentials in this package.

Record evidence in `templates/EVIDENCE.md`. Identify offline computations and unexecuted model/training work separately. Same-user directories are not a secure sandbox.
