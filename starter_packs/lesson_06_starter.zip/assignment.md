# 第 6 课 Guided Lab：Context、Memory 与 Durable State

> 这是一个短 guided lab。先让中断后的运行恢复可信状态，再讨论怎样把轨迹变成评测样本；“记住”与“变好”是两个不同问题。

## 先理解任务，再写代码

前几课我们已经有工具轨迹和任务交接。今天要回答一个更基础的问题：长任务中断后，系统怎样知道哪些信息仍然可信？通过恢复校验的轨迹，才有资格成为后续评测和改进的样本；“记住”与“变好”不是同一个动作。

**项目问题：** 怎样把 Context、Memory 和 Durable State 分开保存，并在环境变化时拒绝不安全恢复？

**项目边界：** 本地 workspace fixture + `DurableSession` + 可重放恢复 trace；不发送用户数据，不使用真实生产日志。

这不是让你调用一个框架并截图。你要提交一条可以被别人重放的执行链：输入、状态、决定、动作、观察、失败原因和最终结果都能找到对应字段。

## 你需要掌握的知识

- 能用自己的话解释本课的 What / Why / How。
- 能画出从用户输入到项目输出的数据流，并标出模型、确定性程序、工具和人工的责任边界。
- 能在正常路径之外，主动构造至少两条失败路径。
- 能读懂项目的 Python 类型、函数参数、返回值、异常和测试断言；不会用“代码能跑”代替解释。

## Notebook 任务顺序

请按 kernel 顺序完成，不要一次性运行全部单元。每个步骤先在 Markdown 中写预测，再执行代码并解释差异。

1. 查看 `SessionSnapshot` 和 `DurableCheckpoint` 的字段。
2. 手算哪些信息属于当前 Context、选择性 Memory 和 Durable State。
3. 运行正常 checkpoint/resume，并指向每个状态变化。
4. 改变 `workspace_digest`，观察 stale checkpoint 的停止结果。
5. 设计 missing checkpoint 和未授权恢复的失败记录。
6. 写出一条准入规则：只有通过 `resume validation` 的轨迹才进入后续 eval。

## 代码政策

assisted_integration：Agent 可辅助生成边界样本和报告模板；评测指标、失败分类、对照实验和发布门必须由学生定义并测试。

可以让 Agent 帮你查 Python 标准库、解释错误、生成非核心测试数据或润色 README；不能把核心状态机、权限/安全边界、评测判定和失败处理交给 Agent 后只提交结果。README 必须列出你亲自设计的部分和 Agent 辅助的部分。

## 必交材料

1. 学生 Notebook：保留每一步的 Markdown 解释和必要输出，不提交 Instructor solution。
2. `README.md`：用 What / Why / How 说明状态对象、恢复规则、运行命令和已知局限。
3. 一条正常轨迹和至少三条失败轨迹（stale、missing、未授权），包含结构化状态字段。
4. 测试：至少一个正常测试、两个边界测试和一个恢复准入测试。
5. 一张数据流图：标出 Context、Memory、checkpoint、验证、停止原因和责任主体。
6. 一段 300–500 字反思：说明一个你原本误解的概念，以及运行结果怎样改变了你的理解。

## 验收清单

- [ ] 固定 fixture 能稳定复现 checkpoint 和 resume 结果。
- [ ] Context、Memory 和 Durable State 的 owner 与生命周期写清楚。
- [ ] stale、missing 和未授权状态都能明确停止，不会静默继续。
- [ ] 恢复前重新检查 task、pending work、workspace digest 和权限。
- [ ] pytest 覆盖正常恢复、环境变化、缺失 checkpoint 和恢复准入。

## 你展示时必须回答的问题

- 为什么完整聊天历史不是恢复状态？
- 摘要和 checkpoint 的责任有什么不同？
- 为什么有 checkpoint 仍然不能直接 resume？
- 什么证据能把一条恢复轨迹送入后续评测？
- 能不能让 Agent 自己决定恢复成功？

## 禁止提交

- 真实客户、真实邮箱、真实 ERP/交易数据、API key、个人隐私或真实机器人控制配置。
- 只有最终答案没有中间状态的截图。
- 把网络不可用、权限拒绝或证据不足伪装成成功。
- 直接复制 Instructor Notebook 的答案单元。

## 运行与提交

```powershell
uv run python scripts/execute_notebooks.py --path notebooks/instructor/lessons/06_agent_improvement_learning.ipynb --timeout 180
uv run pytest tests -q
```

提交前在干净环境重跑 Notebook、测试和 README 中的命令；如果某条路径不能运行，提交它的失败记录和原因，不要删掉失败样例。
