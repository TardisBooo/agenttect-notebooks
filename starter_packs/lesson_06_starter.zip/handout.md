# 第 6 课学习指南：Context、Memory 与 Durable State：让 Agent 记得住、接得上、恢复得了

> 这份页面供学生课前定位、课堂记录和课后复习；请沿着“问题—概念—练习—项目”的顺序使用。

## 本课先回答什么

**核心问题：** 长任务跨轮次、跨设备或跨 Agent 继续时，哪些上下文应该保留、分支、压缩或恢复？

**本课主线：** Context 是当前运行的有限工作集，Memory 是可选择的长期资料，Durable State 是可以校验并恢复的任务事实；只有通过恢复校验、能指向环境结果的轨迹，才适合进入后续评测与改进。

**路线位置：** 本课属于课程主线；它留下的 Work Unit 结构会在第 11–13 课进入最终项目。

## 开始前你需要知道

- 第 3 课的 Verifier、Reflection 和搜索轨迹
- 第 4–5 课的环境后置条件、基线与协作成本

## 学完以后你能够

1. 区分当前 Context、选择性 Memory 和可恢复 Durable State，并说明各自所有者
2. 实现带版本、待办和环境指纹的 checkpoint，并在恢复前验证状态
3. 构造正常、stale、missing checkpoint 和未授权恢复路径
4. 区分 candidate、verifier、selection 与 improvement，并说明它们如何进入 eval
5. 在固定任务和回归集上设计一次只有一个主要变量的改进实验

## 150 分钟学习路线

| 时间 | 学习内容 | 你要完成的动作 |
|---:|---|---|
| 0–12 分钟 | 开场：中断后哪一份状态仍然可信 | 阅读一条摘要成功但环境未确认的恢复轨迹 |
| 12–30 分钟 | 背景：从全量历史到 Context、Memory 与 Durable State | 为当前工作集、长期事实和恢复快照标注所有者 |
| 30–52 分钟 | 第一性原理：checkpoint、digest 与 resume validation | 手算正常恢复、stale 和缺少 checkpoint 的分支 |
| 52–70 分钟 | 可信轨迹如何进入评测与改进 | 区分 candidate、verifier、selection 和 improvement 的责任 |
| 70–80 分钟 | 休息与归因预测题 | 在揭示故障注入位置前先给失败轨迹分类 |
| 80–106 分钟 | Notebook：从状态快照到恢复实验 | 建立 checkpoint、注入 digest 变化并记录 stop_reason |
| 106–132 分钟 | Mini Project：Context Branch 与可恢复 Session | 实现正常、拒绝、失败恢复和可信轨迹准入 |
| 132–143 分钟 | CS329A：Verifier 飞轮与改进方法的边界 | 按生成、验证、选择和改变对象排列方法 |
| 143–150 分钟 | 总结：把可信状态交给下一版评测 | 说明为什么没有独立 Verifier 就不能声称改进 |

## 技术为什么一步步走到今天

| 方法或阶段 | 当时遇到的问题 | 关键改变 | 仍然存在的限制 |
|---|---|---|---|
| 全量历史与对话摘要 | 长任务输入膨胀，摘要又可能丢掉待办和环境版本 | 把当前 Context、选择性 Memory 与 Durable checkpoint 分开 | 状态保存本身不能证明环境仍然有效 |
| 恢复校验与可信轨迹 | checkpoint 存在，但 workspace 或权限可能已经变化 | 恢复前检查 task、pending work、digest 和 owner，再决定继续或停止 | 通过恢复不等于任务结果正确 |
| Eval-driven development 与错误分析 | 多步 Agent 的失败可能来自不同组件，单个成功样例无法比较版本 | 定义 task、trial、verifier、trajectory、outcome 和回归分组 | 评分器或任务集设计错误会把系统优化到错误方向 |
| CS329A：生成、验证、筛选与改进 | 候选生成能力不等于能选出满足环境条件的结果 | 用独立 Verifier 筛选候选，再比较程序、提示、数据或模型改动 | Verifier、预算、分布外任务和安全回归仍需要工程师负责 |
| DSPy、GEPA、SFT 与 RL/RFT | 程序层调整不足，且已有高质量示例或可验证奖励 | 从轨迹和反馈搜索程序变体，或改变训练数据与模型参数 | 数据偏差、奖励投机、成本和能力回归要求更严格评测 |

这张表不是产品年表。阅读时请始终追问：旧方法在哪个条件下失效，新方法增加了哪个中间状态或反馈，它又留下了什么问题？

## 框架镜头

用 pi 的 session tree、Hermes 的长会话与记忆、LangGraph 的 durable execution 对照 Context、Memory 和 Durable State；再用 Stanford CS329A 的 Verifier 飞轮解释可信轨迹为什么才能进入改进。框架保存状态，但不替你判断状态是否可信。

## 本课的 Work Unit 连接

这是一个短 guided lab：先跑通正常、stale、missing checkpoint 和失败恢复路径，再把可信结论带回主项目。

```text
request_id → scope → allowed_actions → observation / evidence
→ postconditions → approval_state → stop_reason → handoff
```

如果本课项目没有涉及某个字段，请在提交说明中写明“为什么暂时不需要”，不要默默省略它。

## 本课关键词

- `context`
- `memory`
- `durable state`
- `checkpoint`
- `resume validation`
- `task and trial`
- `trajectory`
- `outcome`
- `candidate / verifier / selection`
- `improvement loop`

首次遇到不熟悉的词时，先在 Slide 或 Notebook 中找到它的输入、输出和拥有者，再记英文名称。

## Mini Project：Context Branch 与可恢复 Session

**要解决的问题：** 如果一次长任务中断，怎样只恢复可信状态，而不是把整段历史重新塞回模型？

### 需要你自己完成

- Context / Memory / Durable State fields
- versioned checkpoint
- resume validation
- normal / stale / missing recovery paths
- trusted trajectory admission

### Agent 可以怎样协助

- 允许生成报告图表和样板；状态字段、恢复规则、Verifier 和改进选择由学生负责

### 本课代码规则

允许 Agent 辅助搭脚手架；你需要解释关键状态、失败路径和取舍。

### 提交前逐项检查

- [ ] 包含正常、stale、missing checkpoint 和未授权恢复路径
- [ ] 恢复前检查任务、待办、环境 digest 和 owner
- [ ] 记录结构化 stop_reason，并且不把模型文字当作环境事实
- [ ] 只有通过恢复校验的轨迹才进入后续评测或改进对照

预计课后投入：1.25 小时。

## 离开本课前

请不用课程原句、用自己的项目回答：如果模型评分器说新版本更好，但真实数据库状态和单元测试没有改善，你会保留哪一个结论，又该先检查什么？

如果回答中只出现框架名，没有输入、状态、动作、失败或停止条件，请回到 Notebook 的一次完整运行重新说明。
