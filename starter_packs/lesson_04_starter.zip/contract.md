# Context Increment Contract

This is the local public acceptance contract, adapted from AASE Lab01 F2/F3.
It specifies observable behavior, not an internal architecture.

## Invocation

Python 3.12+. From the student project root:

~~~sh
python -m agent_framework --workspace PATH --max-bytes 4096
~~~

Read UTF-8 JSON Lines from stdin. Write exactly one JSON object per input line.
Flush each response. stdout contains only protocol records. Diagnostics use stderr.
EOF ends the process with exit code 0. State exists only in the current process.
Invalid startup arguments use a nonzero exit code.
The workspace must exist and be a directory. max-bytes is an integer in 1..1048576.
The default max-bytes is 4096.

## Requests and success responses

| Request | Success |
|---|---|
| {"action":"add","path":"notes.txt"} | {"ok":true,"paths":["notes.txt"]} |
| {"action":"drop","path":"notes.txt"} | {"ok":true,"paths":[]} |
| {"action":"list"} | {"ok":true,"paths":[...]} |
| {"action":"clear"} | {"ok":true,"paths":[]} |
| {"action":"snapshot"} | {"ok":true,"files":[...],"total_bytes":3} |

Each snapshot file is {"path":"notes.txt","content":"one","bytes":3}.
Sort paths lexicographically. Return relative POSIX paths.
Canonicalize ./notes.txt to notes.txt. Repeated additions remain one selection.
Reject extra fields. Require path only for add/drop. All paths are strings.

Add validates a readable UTF-8 regular file before updating selection.
Drop removes a selected name even if its file was deleted afterward.
Snapshot rereads every selected file. It must never return cached add-time contents.
If any file fails, return one error without partial files and retain all selections.
The total budget counts UTF-8 file bytes only. It is not a token budget.
Each add rejects a file larger than the budget. Snapshot also checks the aggregate.
A zero-byte file is valid. An empty snapshot has files [] and total_bytes 0.

## Errors

Every expected error response is exactly {"ok":false,"error":"CODE"}.
After an error, process the next request with selection unchanged.

| Code | Condition |
|---|---|
| invalid_json | Line is not JSON, including an empty line |
| invalid_request | Wrong command shape, unknown action or extra/missing fields |
| invalid_path | Empty/non-string/NUL path, absolute path, Windows drive or backslash |
| outside_workspace | Any parent path component .. |
| symlink_not_allowed | Any path component is a symbolic link |
| not_found | File is absent when add or snapshot reads it |
| not_file | A path identifies a directory or other non-regular file |
| invalid_utf8 | File bytes cannot be decoded as UTF-8 |
| budget_exceeded | A file or total snapshot exceeds max-bytes |
| not_selected | drop names a path that is not selected |
| read_failed | Other operating-system read failures |

For invalid shapes, report invalid_request before inspecting path contents.
For valid add/drop shapes, validate path syntax and link components before file reads.
For a regular file, enforce the per-file byte bound before decoding UTF-8.

## Boundaries

Never write workspace files, execute shell commands, call a network service or persist sessions.
The workspace is a trusted teaching fixture without concurrent hostile filesystem changes.
Path checks are not an operating-system sandbox and do not cover hard links or race attacks.
Symlink cases require a host that permits symlink creation. Record skips honestly.
The public suite is readable and contains no hidden requirements.
It is not an exhaustive security audit. Add custom tests and explain their defects.
