"""Public black-box checks. Run with --project PATH; no third-party packages."""

import argparse
import json
import os
import subprocess
import sys
import tempfile
import threading
import unittest
from pathlib import Path

PROJECT = Path.cwd()


class Acceptance(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name) / "workspace"
        self.root.mkdir()
        (self.root / "notes.txt").write_text("one", encoding="utf-8")
        (self.root / "other.txt").write_text("two", encoding="utf-8")

    def tearDown(self):
        self.temp.cleanup()

    def run_events(self, events, limit=4096):
        text = "".join(json.dumps(item) + "\n" for item in events)
        return self.run_lines(text, len(events), limit)

    def run_lines(self, text, expected_responses, limit=4096):
        """Exercise raw input as well as valid JSON-shaped requests."""
        env = dict(os.environ, PYTHONIOENCODING="utf-8")
        env.pop("PYTHONPATH", None)
        proc = subprocess.run(
            [
                sys.executable,
                "-m",
                "agent_framework",
                "--workspace",
                str(self.root),
                "--max-bytes",
                str(limit),
            ],
            cwd=PROJECT,
            input=text,
            text=True,
            encoding="utf-8",
            capture_output=True,
            timeout=10,
            env=env,
        )
        self.assertEqual(proc.returncode, 0, proc.stderr)
        output = [json.loads(line) for line in proc.stdout.splitlines()]
        self.assertEqual(len(output), expected_responses, proc.stdout)
        return output

    def test_invalid_json_keeps_selection_and_process_alive(self):
        out = self.run_lines(
            '{"action":"add","path":"notes.txt"}\n'
            'not-json\n\n{"action":"list"}\n',
            4,
        )
        self.assertEqual(out[0], {"ok": True, "paths": ["notes.txt"]})
        self.assertEqual(out[1:3], [{"ok": False, "error": "invalid_json"}] * 2)
        self.assertEqual(out[3], {"ok": True, "paths": ["notes.txt"]})

    def test_invalid_startup_is_rejected(self):
        env = dict(os.environ, PYTHONIOENCODING="utf-8")
        env.pop("PYTHONPATH", None)
        cases = [
            (self.root / "missing", "4096"),
            (self.root / "notes.txt", "4096"),
            (self.root, "0"),
            (self.root, "1048577"),
            (self.root, "not-an-integer"),
        ]
        for workspace, budget in cases:
            with self.subTest(workspace=workspace, budget=budget):
                result = subprocess.run(
                    [sys.executable, "-m", "agent_framework", "--workspace", str(workspace),
                     "--max-bytes", budget],
                    cwd=PROJECT, input="", capture_output=True, text=True,
                    encoding="utf-8", timeout=10, env=env,
                )
                self.assertNotEqual(result.returncode, 0)
                self.assertEqual(result.stdout, "")

    def test_zero_byte_file_is_valid(self):
        (self.root / "empty.txt").write_bytes(b"")
        out = self.run_events(
            [{"action": "add", "path": "empty.txt"}, {"action": "snapshot"}], limit=1
        )
        self.assertEqual(out[0], {"ok": True, "paths": ["empty.txt"]})
        self.assertEqual(out[1], {
            "ok": True,
            "files": [{"path": "empty.txt", "content": "", "bytes": 0}],
            "total_bytes": 0,
        })

    def test_empty_snapshot(self):
        self.assertEqual(
            self.run_events([{"action": "snapshot"}])[0],
            {"ok": True, "files": [], "total_bytes": 0},
        )

    def test_add_snapshot(self):
        out = self.run_events([{"action": "add", "path": "notes.txt"}, {"action": "snapshot"}])
        self.assertEqual(out[0], {"ok": True, "paths": ["notes.txt"]})
        self.assertEqual(
            out[1],
            {
                "ok": True,
                "files": [{"path": "notes.txt", "content": "one", "bytes": 3}],
                "total_bytes": 3,
            },
        )

    def test_duplicate_alias_and_order(self):
        out = self.run_events(
            [{"action": "add", "path": p} for p in ["other.txt", "notes.txt", "./notes.txt"]]
        )
        self.assertEqual(out[-1], {"ok": True, "paths": ["notes.txt", "other.txt"]})

    def test_drop_and_clear(self):
        out = self.run_events(
            [
                {"action": "add", "path": "notes.txt"},
                {"action": "drop", "path": "notes.txt"},
                {"action": "add", "path": "other.txt"},
                {"action": "clear"},
                {"action": "snapshot"},
            ]
        )
        self.assertEqual(out[1], {"ok": True, "paths": []})
        self.assertEqual(out[-1]["files"], [])

    def test_missing_add_preserves_selection(self):
        out = self.run_events(
            [
                {"action": "add", "path": "notes.txt"},
                {"action": "add", "path": "missing.txt"},
                {"action": "list"},
            ]
        )
        self.assertEqual(out[1], {"ok": False, "error": "not_found"})
        self.assertEqual(out[2]["paths"], ["notes.txt"])

    def test_unknown_command_and_extra_fields(self):
        out = self.run_events(
            [
                {"action": "run"},
                {"action": "clear", "path": "notes.txt"},
                [],
                {"action": []},
                {"action": "list"},
            ]
        )
        self.assertTrue(all(x == {"ok": False, "error": "invalid_request"} for x in out[:4]))
        self.assertEqual(out[-1], {"ok": True, "paths": []})

    def test_invalid_path_types(self):
        out = self.run_events([{"action": "add", "path": p} for p in [None, 3, "", "a\x00b"]])
        self.assertTrue(all(x == {"ok": False, "error": "invalid_path"} for x in out))

    def test_parent_and_absolute_paths(self):
        out = self.run_events(
            [
                {"action": "add", "path": "../outside.txt"},
                {"action": "add", "path": str(self.root / "notes.txt")},
                {"action": "add", "path": "C:/outside.txt"},
            ]
        )
        self.assertEqual(
            [x["error"] for x in out], ["outside_workspace", "invalid_path", "invalid_path"]
        )

    def test_directory_and_invalid_utf8(self):
        (self.root / "bad.txt").write_bytes(bytes([255]))
        out = self.run_events(
            [{"action": "add", "path": "."}, {"action": "add", "path": "bad.txt"}]
        )
        self.assertEqual([x["error"] for x in out], ["not_file", "invalid_utf8"])

    def test_utf8_byte_budget(self):
        (self.root / "cn.txt").write_text("中", encoding="utf-8")
        out = self.run_events(
            [{"action": "add", "path": "cn.txt"}, {"action": "snapshot"}], limit=3
        )
        self.assertEqual(out[-1]["total_bytes"], 3)
        self.assertEqual(
            self.run_events([{"action": "add", "path": "cn.txt"}], limit=2)[0]["error"],
            "budget_exceeded",
        )

    def test_aggregate_budget_is_atomic(self):
        out = self.run_events(
            [
                {"action": "add", "path": "notes.txt"},
                {"action": "add", "path": "other.txt"},
                {"action": "snapshot"},
                {"action": "list"},
            ],
            limit=5,
        )
        self.assertEqual(out[2], {"ok": False, "error": "budget_exceeded"})
        self.assertEqual(out[3]["paths"], ["notes.txt", "other.txt"])

    def test_no_workspace_writes(self):
        before = {p.name: p.read_bytes() for p in self.root.iterdir()}
        self.run_events(
            [{"action": "add", "path": "notes.txt"}, {"action": "snapshot"}, {"action": "clear"}]
        )
        self.assertEqual(before, {p.name: p.read_bytes() for p in self.root.iterdir()})

    def test_missing_drop(self):
        self.assertEqual(
            self.run_events([{"action": "drop", "path": "notes.txt"}])[0],
            {"ok": False, "error": "not_selected"},
        )

    def test_current_reads_and_failure_recovery(self):
        env = dict(os.environ, PYTHONIOENCODING="utf-8")
        env.pop("PYTHONPATH", None)
        proc = subprocess.Popen(
            [sys.executable, "-u", "-m", "agent_framework", "--workspace", str(self.root)],
            cwd=PROJECT,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            env=env,
        )

        def exchange(item):
            proc.stdin.write(json.dumps(item) + "\n")
            proc.stdin.flush()
            return json.loads(proc.stdout.readline())

        watchdog = threading.Timer(10, proc.kill)
        watchdog.start()
        try:
            self.assertTrue(exchange({"action": "add", "path": "notes.txt"})["ok"])
            (self.root / "notes.txt").write_text("changed", encoding="utf-8")
            self.assertEqual(exchange({"action": "snapshot"})["files"][0]["content"], "changed")
            (self.root / "notes.txt").unlink()
            self.assertEqual(exchange({"action": "snapshot"}), {"ok": False, "error": "not_found"})
            self.assertEqual(exchange({"action": "list"})["paths"], ["notes.txt"])
            (self.root / "notes.txt").write_text("restored", encoding="utf-8")
            self.assertEqual(exchange({"action": "snapshot"})["files"][0]["content"], "restored")
            (self.root / "notes.txt").unlink()
            self.assertEqual(exchange({"action": "drop", "path": "notes.txt"}),
                             {"ok": True, "paths": []})
        finally:
            watchdog.cancel()
            proc.stdin.close()
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
            proc.stdout.close()
            proc.stderr.close()
            self.assertEqual(proc.returncode, 0)

    def test_symlink_is_rejected(self):
        try:
            (self.root / "link.txt").symlink_to(self.root / "notes.txt")
        except OSError:
            self.skipTest("symlink creation unavailable on this host")
        self.assertEqual(
            self.run_events([{"action": "add", "path": "link.txt"}])[0],
            {"ok": False, "error": "symlink_not_allowed"},
        )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", type=Path, required=True)
    args, remaining = parser.parse_known_args()
    PROJECT = args.project.resolve()
    unittest.main(argv=[sys.argv[0], *remaining])
