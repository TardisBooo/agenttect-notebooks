"""Additional public state-transition checks; these do not simulate an AI handoff."""

import argparse
import json
import os
import subprocess
import sys
import tempfile
import threading
import unittest
from contextlib import contextmanager
from pathlib import Path

PROJECT = Path.cwd()


@contextmanager
def session(workspace, budget=4096):
    env = dict(os.environ, PYTHONIOENCODING="utf-8")
    env.pop("PYTHONPATH", None)
    process = subprocess.Popen(
        [sys.executable, "-u", "-m", "agent_framework", "--workspace", str(workspace),
         "--max-bytes", str(budget)],
        cwd=PROJECT, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, encoding="utf-8", env=env,
    )
    watchdog = threading.Timer(12, process.kill)
    watchdog.start()

    def exchange(request):
        process.stdin.write(json.dumps(request) + "\n")
        process.stdin.flush()
        line = process.stdout.readline()
        if not line:
            raise AssertionError("CLI closed before returning a response")
        return json.loads(line)

    try:
        yield exchange
    finally:
        watchdog.cancel()
        process.stdin.close()
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
        process.stdout.close()
        process.stderr.close()
        if process.returncode != 0:
            raise AssertionError(f"CLI exit code {process.returncode}")


class StateTransitions(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def test_multibyte_exact_aggregate_and_growth_recovery(self):
        (self.root / "a.txt").write_text("中", encoding="utf-8")
        (self.root / "b.txt").write_text("文", encoding="utf-8")
        with session(self.root, 6) as exchange:
            for path in ["a.txt", "b.txt"]:
                self.assertTrue(exchange({"action": "add", "path": path})["ok"])
            self.assertEqual(exchange({"action": "snapshot"})["total_bytes"], 6)
            (self.root / "b.txt").write_text("文字", encoding="utf-8")
            self.assertEqual(exchange({"action": "snapshot"}),
                             {"ok": False, "error": "budget_exceeded"})
            self.assertEqual(exchange({"action": "list"})["paths"], ["a.txt", "b.txt"])
            (self.root / "b.txt").write_text("文", encoding="utf-8")
            self.assertEqual(exchange({"action": "snapshot"})["total_bytes"], 6)

    def test_invalid_utf8_after_selection_is_atomic_and_recoverable(self):
        for name in ["a.txt", "b.txt"]:
            (self.root / name).write_text("ok", encoding="utf-8")
        with session(self.root) as exchange:
            for path in ["a.txt", "b.txt"]:
                self.assertTrue(exchange({"action": "add", "path": path})["ok"])
            (self.root / "b.txt").write_bytes(b"\xff")
            self.assertEqual(exchange({"action": "snapshot"}),
                             {"ok": False, "error": "invalid_utf8"})
            self.assertEqual(exchange({"action": "list"})["paths"], ["a.txt", "b.txt"])
            (self.root / "b.txt").write_text("restored", encoding="utf-8")
            self.assertEqual([f["content"] for f in exchange({"action": "snapshot"})["files"]],
                             ["ok", "restored"])

    def test_selection_is_not_persisted_between_processes(self):
        (self.root / "a.txt").write_text("one", encoding="utf-8")
        with session(self.root) as exchange:
            self.assertTrue(exchange({"action": "add", "path": "a.txt"})["ok"])
        with session(self.root) as exchange:
            self.assertEqual(exchange({"action": "snapshot"}),
                             {"ok": True, "files": [], "total_bytes": 0})


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", type=Path, required=True)
    args, remaining = parser.parse_known_args()
    PROJECT = args.project.resolve()
    unittest.main(argv=[sys.argv[0], *remaining])
