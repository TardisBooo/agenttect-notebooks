# Context snapshot increment

Python 3.12 or later. No API credential is required.

Read assignment.md and contract.md before implementation.
Create your own `agent_framework` package in this directory.
This starter contains requirements and public tests, not application code.
Tests are expected to fail until you implement the package.
The fixture folder is an input workspace, not a place for application code.

Use the documents in this order:

1. Record inspected code and unknowns in `docs/RESEARCH.md`.
2. Define observable scenarios in `docs/SPEC.md`.
3. Compare implementations in `docs/DESIGN.md`.
4. Plan and track small changes in `docs/TASKS.md`.
5. Record actual checks in `evidence/INDEX.md`.
6. Use `docs/HANDOFF.md` to start an independent handoff.

Record consequential AI suggestions and verification in `AI_LOG.md`.
Templates are blank. They are not completed evidence.

```sh
python -m agent_framework --workspace fixtures --max-bytes 4096
python tests/acceptance.py --project . -v
python tests/handoff_acceptance.py --project . -v
```

The first command reads JSON Lines from stdin. Start with:

```json
{"action":"add","path":"notes.txt"}
{"action":"snapshot"}
```

Each line should return one JSON response. The snapshot should contain the
current text of `fixtures/notes.txt`. Send EOF to exit: Ctrl+Z then Enter on
Windows, or Ctrl+D on macOS/Linux.

The public suites create temporary file fixtures and invoke real CLI processes.
Despite its name, `handoff_acceptance.py` does not start a fresh AI conversation.
Complete the manual handoff from `assignment.md` and record what actually happened.

Keep stdout limited to protocol responses. Use stderr for diagnostics.
Do not call a model, shell, or network from the application.
The budget measures UTF-8 content bytes, not model tokens.

The lesson 3.5 DeepSeek demo remains unchanged. This increment is a separate
module. A later adapter may use its snapshots when assembling model input.
Do not fabricate tool calls to insert file content into a conversation.

Document architecture, tests, known limitations and source attributions.
Never store API keys or personal content in evidence files.
