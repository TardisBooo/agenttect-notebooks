# Empty implementation directory

Create `workflow_lab/__init__.py` and `workflow_lab/__main__.py` here.
Implement the commands and behavior in `../contract.md`.
The public tests invoke `python -m workflow_lab` in a fresh process.
No functions, command handlers, or completed Skill are supplied.
