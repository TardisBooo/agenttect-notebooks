"""Workflow orchestration engine: prompt chaining, explicit routing, and fan-out/fan-in."""

import json
import math
import time
from concurrent.futures import ThreadPoolExecutor, wait

try:
    from .gates import snapshot_files, task_config, validate_records, validate_result
    from .models import Invalid, digest, require
except (ImportError, ValueError):
    from workflow_lab.gates import snapshot_files, task_config, validate_records, validate_result
    from workflow_lab.models import Invalid, digest, require


def extract(item, task):
    """Deterministic branch extractor with fault injection support."""
    path = item["path"]
    time.sleep(task.get("delay_ms", {}).get(path, 0) / 1000)
    fault = task.get("faults", {}).get(path)
    if fault == "timeout":
        raise Invalid("BRANCH_TIMEOUT")
    if fault == "bad_json":
        raise Invalid("INVALID_EXTRACTION")
    if task["kind"] == "qa":
        record = {"path": path, "claim": "Document excerpt", "evidence": item["content"]}
    else:
        try:
            value = json.loads(item["content"])
        except (ValueError, TypeError) as exc:
            raise Invalid("INVALID_EXTRACTION") from exc
        require(isinstance(value, dict), "INVALID_EXTRACTION")
        record = {**value, "path": path, "evidence": item["content"]}
        if fault == "missing_unit":
            record.pop("unit", None)
    if fault == "unsupported_evidence":
        record["evidence"] = "invented quote"
    return record


def execute(snapshot, task, baseline=False, extractor=extract):
    """
    【学生任务 2：执行复合工作流引擎】
    包含：
      1. 显式路由 (Explicit Router)
      2. 提示链与多线程并行扇出 (Parallel Fan-Out)
      3. 截止时间超时熔断 (Deadline Monitoring)
      4. 语义门禁校验与差值聚合 (Fan-In Aggregator)
    """
    started = time.perf_counter()
    files, snapshot_hash = snapshot_files(snapshot)
    paths, deadline = task_config(task, files)
    result = {
        "schema": "workflow-report/v1",
        "status": "rejected",
        "snapshot_sha256": snapshot_hash,
        "adapter": "fixture",
        "route": task["kind"],
        "steps": [],
        "report": None,
        "report_sha256": None,
        "errors": [],
        "metrics": {"calls": 0, "elapsed_ms": 0},
    }

    def step(name, status="passed", code=None, selected=None):
        result["steps"].append(
            {
                "id": name,
                "status": status,
                "input_paths": paths if selected is None else selected,
                "error_code": code,
            }
        )

    step("snapshot")

    # ========================== TODO: START HERE (Router) ==========================
    # 步骤 1: 检查 task["kind"] 是否在 ("qa", "compare") 中
    # 步骤 2: 若为不支持的任务，记录 step("route", "failed", "UNSUPPORTED_TASK")，并向 result["errors"] 追加错误码
    if task["kind"] not in ("qa", "compare"):
        step("route", "failed", "UNSUPPORTED_TASK")
        result["errors"].append("UNSUPPORTED_TASK")
        step("report", "skipped")
    # =========================== TODO: END HERE =====================================
    else:
        step("route")
        records = []
        if baseline:
            result["metrics"]["calls"] = 1
            try:
                records = [extractor(files[p], task) for p in paths]
                require((time.perf_counter() - started) * 1000 <= deadline, "BRANCH_TIMEOUT")
                step("baseline")
            except Invalid as exc:
                result["errors"].append(str(exc))
                step("baseline", "failed", str(exc))
        else:
            # ========================== TODO: START HERE (Parallel Fan-Out) =================
            # 步骤 1: 记录调用次数 result["metrics"]["calls"] = len(paths)
            # 步骤 2: 使用 ThreadPoolExecutor(max_workers=min(4, len(paths))) 并行提交提取任务
            # 步骤 3: 使用 wait(futures.values(), timeout=deadline / 1000) 收集结果
            # 步骤 4: 检查每个 future 是否在 done 集合中，若超时抛出 require(future in done, "BRANCH_TIMEOUT")
            # 步骤 5: 成功提取时追加到 records，并记录 step("extract:" + path, selected=[path])
            result["metrics"]["calls"] = len(paths)
            pool = ThreadPoolExecutor(max_workers=min(4, len(paths)))
            futures = {p: pool.submit(extractor, files[p], task) for p in paths}
            done, _ = wait(futures.values(), timeout=deadline / 1000)
            for path, future in futures.items():
                try:
                    require(future in done, "BRANCH_TIMEOUT")
                    records.append(future.result())
                    step("extract:" + path, selected=[path])
                except Invalid as exc:
                    result["errors"].append(str(exc))
                    step("extract:" + path, "failed", str(exc), [path])
            pool.shutdown(wait=True, cancel_futures=True)
            # =========================== TODO: END HERE =====================================

        if result["errors"]:
            step("gate", "skipped")
            step("report", "skipped")
        else:
            try:
                validate_records(records, paths, files, task["kind"])
                if task["kind"] == "compare":
                    left, right = records
                    delta = right["value"] - left["value"]
                    require(math.isfinite(delta), "INVALID_VALUE")
                    summary = (
                        f"{right['path']} minus {left['path']}: "
                        f"{delta:g} {left['unit']} ({left['period']})."
                    )
                    findings = [
                        {
                            "path": r["path"],
                            "claim": (
                                f"value={r['value']:g}; unit={r['unit']}; period={r['period']}"
                            ),
                            "evidence": r["evidence"],
                        }
                        for r in records
                    ]
                else:
                    summary, findings = "Selected document excerpts.", records
                step("gate")
                result["report"] = {"summary": summary, "findings": findings}
                result["report_sha256"] = digest(result["report"])
                result["status"] = "validated"
                step("report")
            except (Invalid, OverflowError) as exc:
                code = "INVALID_VALUE" if isinstance(exc, OverflowError) else str(exc)
                result["errors"].append(code)
                step("gate", "failed", code)
                step("report", "skipped")

    result["metrics"]["elapsed_ms"] = round((time.perf_counter() - started) * 1000)
    validate_result(result)
    return result
