"""Data models, exceptions, and serialization helpers for workflow_lab."""

import hashlib
import json
from pathlib import Path


class Invalid(ValueError):
    """Domain error representing protocol or validation failure."""
    pass


def reject_constant(value):
    raise Invalid("INVALID_JSON")


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"), parse_constant=reject_constant)


def canonical(value):
    """Serialize JSON with deterministic canonical formatting."""
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    )


def digest(value):
    """Calculate SHA-256 hex digest of canonical JSON serialization."""
    return hashlib.sha256(canonical(value).encode("utf-8")).hexdigest()


def require(condition, code):
    """Assert condition or raise Invalid error code."""
    if not condition:
        raise Invalid(code)
