"""Semantic gates and structure validators for workflow_lab."""

import math
import re
from pathlib import PurePosixPath

try:
    from .models import Invalid, digest, require
except (ImportError, ValueError):
    from workflow_lab.models import Invalid, digest, require


def snapshot_files(snapshot):
    """Validate snapshot structure and compute digest."""
    require(isinstance(snapshot, dict) and snapshot.get("ok") is True, "INVALID_SNAPSHOT")
    files = snapshot.get("files")
    require(isinstance(files, list) and bool(files), "INVALID_SNAPSHOT")
    by_path = {}
    for item in files:
        require(isinstance(item, dict), "INVALID_SNAPSHOT")
        path, content, size = item.get("path"), item.get("content"), item.get("bytes")
        require(
            isinstance(path, str) and bool(path) and "\\" not in path and ":" not in path,
            "INVALID_PATH",
        )
        require(
            not PurePosixPath(path).is_absolute()
            and all(p not in ("", ".", "..") for p in path.split("/")),
            "INVALID_PATH",
        )
        require(path not in by_path, "DUPLICATE_PATH")
        require(
            isinstance(content, str) and type(size) is int and size == len(content.encode("utf-8")),
            "BYTE_MISMATCH",
        )
        by_path[path] = {"path": path, "content": content, "bytes": size}
    total = sum(item["bytes"] for item in by_path.values())
    require(
        type(snapshot.get("total_bytes")) is int and snapshot["total_bytes"] == total,
        "BYTE_MISMATCH",
    )
    return by_path, digest({"files": [by_path[p] for p in sorted(by_path)], "total_bytes": total})


def task_config(task, files):
    """Validate task parameters, routes, deadlines, and fault injection configuration."""
    require(isinstance(task, dict) and isinstance(task.get("kind"), str), "INVALID_TASK")
    paths = task.get("paths")
    require(
        isinstance(paths, list) and bool(paths) and all(isinstance(p, str) for p in paths),
        "INVALID_TASK",
    )
    require(len(set(paths)) == len(paths) and all(p in files for p in paths), "UNKNOWN_PATH")
    require(task["kind"] != "compare" or len(paths) == 2, "INVALID_TASK")
    deadline = task.get("deadline_ms", 1000)
    require(type(deadline) is int and 1 <= deadline <= 5000, "INVALID_TASK")
    for field in ("faults", "delay_ms"):
        values = task.get(field, {})
        require(isinstance(values, dict) and all(p in paths for p in values), "INVALID_TASK")
    require(
        all(
            v in ("timeout", "bad_json", "missing_unit", "unsupported_evidence")
            for v in task.get("faults", {}).values()
        ),
        "INVALID_TASK",
    )
    require(
        all(type(v) is int and 0 <= v <= 1000 for v in task.get("delay_ms", {}).values()),
        "INVALID_TASK",
    )
    return paths, deadline


def validate_records(records, paths, files, kind):
    """
    【学生任务 1：四层语义门禁检查】
    入参:
      - records: 提取出的记录列表 (List[Dict])
      - paths: 预期的路径列表 (List[str])
      - files: 快照文件字典 (Dict[str, Dict])
      - kind: 任务类型 ("qa" 或 "compare")
    """
    require(
        len(records) == len(paths) and {r.get("path") for r in records} == set(paths),
        "INCOMPLETE_BRANCHES",
    )
    for record in records:
        evidence = record.get("evidence")
        # ========================== TODO: START HERE (Evidence Check) ==========================
        # 步骤 1: 确保 evidence 为非空字符串
        # 步骤 2: 确保 evidence 精确包含在快照正文 files[record["path"]]["content"] 中
        # 若不满足，抛出 Invalid("UNSUPPORTED_EVIDENCE") 或 require(..., "UNSUPPORTED_EVIDENCE")
        require(
            isinstance(evidence, str)
            and bool(evidence)
            and evidence in files[record["path"]]["content"],
            "UNSUPPORTED_EVIDENCE",
        )
        # =========================== TODO: END HERE ============================================

        if kind == "compare":
            require(isinstance(record.get("unit"), str) and bool(record["unit"]), "MISSING_UNIT")
            require(
                isinstance(record.get("period"), str) and bool(record["period"]), "MISSING_PERIOD"
            )
            value = record.get("value")
            require(type(value) in (int, float) and math.isfinite(value), "INVALID_VALUE")

    if kind == "compare":
        # ========================== TODO: START HERE (Unit & Period Alignment) =================
        # 步骤 1: 比较任务下，所有记录的 unit 必须完全相同，否则抛出 require(..., "UNIT_MISMATCH")
        # 步骤 2: 比较任务下，所有记录的 period 必须完全相同，否则抛出 require(..., "PERIOD_MISMATCH")
        require(len({r["unit"] for r in records}) == 1, "UNIT_MISMATCH")
        require(len({r["period"] for r in records}) == 1, "PERIOD_MISMATCH")
        # =========================== TODO: END HERE ============================================


def validate_result(result):
    """Validate workflow report schema conformity and cryptographic digest."""
    require(
        isinstance(result, dict) and result.get("schema") == "workflow-report/v1", "INVALID_RESULT"
    )
    require(
        result.get("adapter") == "fixture" and result.get("status") in ("validated", "rejected"),
        "INVALID_RESULT",
    )
    require(
        isinstance(result.get("snapshot_sha256"), str)
        and re.fullmatch(r"[0-9a-f]{64}", result["snapshot_sha256"]),
        "INVALID_RESULT",
    )
    require(isinstance(result.get("route"), str) and bool(result["route"]), "INVALID_RESULT")
    require(
        isinstance(result.get("steps"), list)
        and bool(result["steps"])
        and isinstance(result.get("errors"), list),
        "INVALID_RESULT",
    )
    require(all(isinstance(e, str) and bool(e) for e in result["errors"]), "INVALID_RESULT")
    require(isinstance(result.get("metrics"), dict), "INVALID_RESULT")
    require(
        type(result["metrics"].get("calls")) is int and result["metrics"]["calls"] >= 0,
        "INVALID_RESULT",
    )
    require(
        type(result["metrics"].get("elapsed_ms")) is int and result["metrics"]["elapsed_ms"] >= 0,
        "INVALID_RESULT",
    )
    for step in result["steps"]:
        require(
            isinstance(step, dict)
            and isinstance(step.get("id"), str)
            and bool(step["id"])
            and step.get("status") in ("passed", "failed", "skipped"),
            "INVALID_RESULT",
        )
        require(
            isinstance(step.get("input_paths"), list)
            and all(isinstance(p, str) for p in step["input_paths"]),
            "INVALID_RESULT",
        )
        error_code = step.get("error_code")
        require(
            isinstance(error_code, str) and bool(error_code)
            if step["status"] == "failed"
            else "error_code" in step and error_code is None,
            "INVALID_RESULT",
        )
    ids = [s["id"] for s in result["steps"]]
    require(
        len(set(ids)) == len(ids) and {"snapshot", "route", "report"}.issubset(ids),
        "INVALID_RESULT",
    )
    if result["status"] == "rejected":
        require(
            bool(result["errors"])
            and result.get("report") is None
            and result.get("report_sha256") is None,
            "INVALID_RESULT",
        )
        return
    report = result.get("report")
    require(result["route"] in ("qa", "compare") and "gate" in ids, "INVALID_RESULT")
    require(not result["errors"] and isinstance(report, dict), "INVALID_RESULT")
    require(
        isinstance(report.get("summary"), str) and bool(report["summary"].strip()), "INVALID_RESULT"
    )
    require(isinstance(report.get("findings"), list) and bool(report["findings"]), "INVALID_RESULT")
    for finding in report["findings"]:
        require(
            isinstance(finding, dict)
            and all(
                isinstance(finding.get(k), str) and bool(finding[k])
                for k in ("path", "claim", "evidence")
            ),
            "INVALID_RESULT",
        )
    require(result.get("report_sha256") == digest(report), "REPORT_DIGEST_MISMATCH")
    require(all(s["status"] == "passed" for s in result["steps"]), "INVALID_RESULT")
