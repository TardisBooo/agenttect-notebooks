"""Command line interface and entrypoint for workflow_lab."""

import argparse
import sys
from pathlib import Path

_PKG_ROOT = Path(__file__).resolve().parents[1]
if str(_PKG_ROOT) not in sys.path:
    sys.path.insert(0, str(_PKG_ROOT))

try:
    from .engine import execute as engine_execute
    from .engine import extract as engine_extract
    from .gates import validate_result
    from .models import Invalid, canonical, read_json
except (ImportError, ValueError):
    from workflow_lab.engine import execute as engine_execute
    from workflow_lab.engine import extract as engine_extract
    from workflow_lab.gates import validate_result
    from workflow_lab.models import Invalid, canonical, read_json


def extract(item, task):
    """Re-exported extractor function (supports test harness patching)."""
    return engine_extract(item, task)


def execute(snapshot, task, baseline=False):
    """Execute workflow using the current module's extract function."""
    current_module = sys.modules.get(__name__)
    active_extract = getattr(current_module, "extract", extract) if current_module else extract
    return engine_execute(snapshot, task, baseline=baseline, extractor=active_extract)


def main():
    parser = argparse.ArgumentParser(description="Lesson 05 Snapshot Workflow CLI")
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ("run", "baseline"):
        command = commands.add_parser(name)
        command.add_argument("--snapshot", required=True)
        command.add_argument("--task", required=True)
        command.add_argument("--adapter", choices=["fixture"], required=True)
        command.add_argument("--output", required=True)
    command = commands.add_parser("verify")
    command.add_argument("--result", required=True)
    args = parser.parse_args()
    try:
        if args.command == "verify":
            result = read_json(args.result)
            validate_result(result)
            print(
                canonical(
                    {"ok": True, "status": result["status"], "scope": "structure_and_digest_only"}
                )
            )
            return 0
        result = execute(read_json(args.snapshot), read_json(args.task), args.command == "baseline")
        Path(args.output).write_text(canonical(result) + "\n", encoding="utf-8")
        print(canonical(result))
        return 0 if result["status"] == "validated" else 1
    except (OSError, ValueError, TypeError, OverflowError) as exc:
        code = str(exc) if isinstance(exc, Invalid) else "INPUT_ERROR"
        print(canonical({"ok": False, "error_code": code}))
        return 2


if __name__ == "__main__":
    sys.exit(main())
