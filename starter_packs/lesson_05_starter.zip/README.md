# Workflow lab starter

Implement the `workflow_lab` module in `implementation/`.
The archive intentionally contains no implementation or completed Skill.
Read `contract.md` before writing code. All fixtures are synthetic.

Use Python 3.11 or newer. No third-party packages or API keys are required.
Run these commands from the extracted student directory in PowerShell.

```powershell
$env:PYTHONPATH = (Resolve-Path implementation).Path
python -m workflow_lab run --snapshot fixtures/snapshot.json --task fixtures/task-compare.json --adapter fixture --output result.json
python -m workflow_lab baseline --snapshot fixtures/snapshot.json --task fixtures/task-compare.json --adapter fixture --output baseline.json
python -m workflow_lab verify --result result.json
python tests/acceptance.py --project implementation -v
```

The baseline and workflow share the same acceptance criteria.
`calls` counts logical fixture-adapter requests, not LLM API requests.
`elapsed_ms` includes fixture delays and local execution overhead.
Do not infer model quality, API cost, or stable speedups from these metrics.

The public suite runs actual CLI subprocesses. It does not run model-based
Skill trigger tests. Fill `templates/trigger-cases.json` only after observing
real Agent behavior. Save complete Skill execution evidence separately.

Test input and output directories remain under `tmp/workflow-acceptance` for
review. Use `--scratch PATH` to select another test-evidence directory.
These generated directories are review evidence, not accepted deliverables.

Do not include personal documents, credentials, or raw service traffic.
