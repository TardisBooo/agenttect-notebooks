# 文件快照工作流公开契约

## Scope

本课从第 4 课的成功快照生成只读报告。
路径名称只标识快照成员，不触发磁盘读取。
`fixture` 是确定性教学适配器，不调用模型。
它检验控制流程，不能证明模型理解或答案质量。

命令空间为 `workflow_lab`。
Python 使用标准库即可运行本项目。

## Snapshot

输入对象包含 `ok: true`、`files` 和 `total_bytes`。
`files` 是非空列表。
每个文件含 `path`、`content` 和 `bytes`。
`content` 是字符串。
`bytes` 等于正文编码为 UTF-8 后的字节数。
布尔值不是合法字节数。
`total_bytes` 等于所有 `bytes` 的和。

`path` 是唯一的非空相对 POSIX 路径。
路径禁止反斜杠、冒号和绝对路径。
路径段禁止空字符串、`.` 和 `..`。
快照中的文件可按任意顺序排列。
重复路径返回 `DUPLICATE_PATH`。
字节数错误返回 `BYTE_MISMATCH`。
路径错误返回 `INVALID_PATH`。
其他快照结构错误返回 `INVALID_SNAPSHOT`。

## Task and semantic gate

任务对象包含 `kind` 和 `paths`。
`kind` 必须是字符串。
`paths` 是非空、无重复的路径列表。
每个路径必须属于快照。
重复或未知路径返回 `UNKNOWN_PATH`。
缺失或错误类型返回 `INVALID_TASK`。

`compare` 恰好选择两份文档。
两份文档比较同一期间的两个对象。
本版不比较不同期间，也不换算单位。
每份合成文档的正文是一个 JSON 对象。
对象包含 `period`、`unit` 和 `value`。
`period` 和 `unit` 是非空字符串。
`value` 是有限数值，禁止布尔值。
比较顺序是 `paths[1]` 减 `paths[0]`。
摘要格式为 `b.json minus a.json: 30 items (2025).`。
路径、差值、单位和期间随实际输入变化。
数值格式使用 Python 的 `g` 格式。

必需分支集合恰好等于 `paths` 中的路径集合。
每个路径必须恰好返回一条发现记录。
发现记录包含 `path`、`claim` 和 `evidence`。
三个字段均为非空字符串。
`evidence` 必须是对应快照正文的精确子串。
`findings` 按任务路径顺序排列。
运行入口必须检查成员、证据和完整性。
缺分支返回 `INCOMPLETE_BRANCHES`。
引文不受支持返回 `UNSUPPORTED_EVIDENCE`。
缺单位或期间分别返回 `MISSING_UNIT`、`MISSING_PERIOD`。
单位不同返回 `UNIT_MISMATCH`。
期间不同返回 `PERIOD_MISMATCH`。
非法数值或计算溢出返回 `INVALID_VALUE`。
解析失败返回 `INVALID_EXTRACTION`。

## Routes

`qa` 接受至少一个路径。
本版只实现只读摘录，不模拟自然语言问答。
每条摘录的 `claim` 为 `Document excerpt`。
`evidence` 使用对应正文。
报告摘要为 `Selected document excerpts.`。
摘录不要求数值字段。
空正文不能提供非空证据，应拒绝。

`compare` 使用前述比较规则。
其他字符串类别返回 `UNSUPPORTED_TASK`。
不支持的类别不调用适配器，`calls` 为 0。
它们产生合法拒绝报告，而非启动错误。
显式 `kind` 路由不证明模型能分类自然语言。

## Fixture controls

任务可含 `faults`、`delay_ms` 和 `deadline_ms`。
这些字段只用于教学故障注入。
`faults` 和 `delay_ms` 是以所选路径为键的对象。
未知键或非法值返回 `INVALID_TASK`。

| 字段值 | 行为 |
| --- | --- |
| `faults[path]="timeout"` | 分支直接返回 `BRANCH_TIMEOUT` |
| `faults[path]="bad_json"` | 分支返回 `INVALID_EXTRACTION` |
| `faults[path]="missing_unit"` | 删除比较记录中的单位 |
| `faults[path]="unsupported_evidence"` | 返回原文中不存在的证据 |
| `delay_ms[path]` | 等待指定毫秒数，范围为 0 至 1000 |
| `deadline_ms` | 收集截止时间，范围为 1 至 5000，默认 1000 |

## Fan-in policy

`run` 并行启动独立提取，最多使用四个工作线程。
合并者按 `paths` 顺序读取分支结果。
任何必需分支失败，整次任务拒绝。
已完成分支仍保留步骤记录。
检查失败后，报告步骤标为 `skipped`。
不输出半份 `validated` 报告。

## Deadline semantics

`run` 的截止时间限制收集结果的等待。
截止前未完成的分支返回 `BRANCH_TIMEOUT`。
已启动的线程可以继续运行。
参考实现退出前等待测试线程收尾。
因此截止时间不是 CLI 总时长上限。
它也不承诺取消外部请求或操作系统线程。

`baseline` 在一次逻辑适配器调用中处理所有路径。
参考适配器内部依次解析各文档。
基线在解析后检查总处理时长。
它超过相同截止条件时也拒绝。
两个入口共享数据、成功条件和输出规则。
`calls` 是逻辑适配器调用数，不是模型请求数。
`elapsed_ms` 是本次执行函数的墙钟毫秒数。
这些指标不能直接用于模型性能或费用声明。

## Canonical JSON and hashes

规范 JSON 使用以下固定规则。

```python
json.dumps(
    value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
).encode("utf-8")
```

快照摘要计算对象只有 `files` 和 `total_bytes`。
文件按 `path` 排序。
每条记录只有 `path`、`content`、`bytes`。
`ok` 不参与摘要。
`snapshot_sha256` 使用 SHA-256 小写十六进制。
`report_sha256` 对规范化的 `report` 计算。
摘要证明内容一致性，不证明真实性或作者身份。

## Result

结果对象遵守以下结构。

```json
{
  "schema": "workflow-report/v1",
  "status": "validated",
  "snapshot_sha256": "64 lowercase hexadecimal characters",
  "adapter": "fixture",
  "route": "compare",
  "steps": [{"id": "snapshot", "status": "passed", "input_paths": ["a.json", "b.json"], "error_code": null}],
  "report": {"summary": "...", "findings": [{"path": "a.json", "claim": "...", "evidence": "..."}]},
  "report_sha256": "64 lowercase hexadecimal characters",
  "errors": [],
  "metrics": {"calls": 2, "elapsed_ms": 0}
}
```

上例仅展示字段形状，不是完整成功结果。
步骤 ID 必须非空且唯一。
所有结果都包含 `snapshot`、`route` 和 `report`。
成功结果还包含 `gate`。
工作流另含 `extract:<path>`，基线另含 `baseline`。
步骤状态只允许 `passed`、`failed`、`skipped`。
`input_paths` 是字符串列表。
失败步骤含非空 `error_code`，其他步骤为 `null`。
成功结果的所有步骤均为 `passed`。
`errors` 是字符串列表。
指标是非负整数。

拒绝结果的 `status` 为 `rejected`。
它的 `report` 和 `report_sha256` 均为 `null`。
拒绝结果至少包含一个错误码。
成功结果的 `errors` 为空。
成功报告含非空摘要和非空发现列表。

## Commands and exit codes

```text
python -m workflow_lab run --snapshot PATH --task PATH --adapter fixture --output PATH
python -m workflow_lab baseline --snapshot PATH --task PATH --adapter fixture --output PATH
python -m workflow_lab verify --result PATH
```

`run` 和 `baseline` 写出 UTF-8 JSON 文件。
输出文件的父目录必须存在。
标准输出返回同一 JSON 对象。
成功报告退出码为 0。
任务拒绝退出码为 1。
输入或文件错误退出码为 2。
这些错误返回 `{"ok":false,"error_code":"..."}`。
无效 JSON 或不可读文件返回 `INPUT_ERROR`。
JSON 中的非有限常量返回 `INVALID_JSON`。
参数语法错误遵守 argparse 的退出码 2。
参数语法错误输出帮助文本，不属于结果协议。

## verify

`verify` 检查结构和报告摘要。
格式错误返回 `INVALID_RESULT`。
摘要不一致返回 `REPORT_DIGEST_MISMATCH`。
验证成功退出码为 0，并输出以下对象。

```json
{"ok":true,"status":"validated","scope":"structure_and_digest_only"}
```

合法拒绝结果同样可以通过 `verify`。
此时返回的 `status` 为 `rejected`。
`verify` 不接收原快照和原任务。
因此它不能重查证据、所选路径和必需分支。
结果中的检查记录也不是独立来源证明。
攻击者可以修改内容并重算摘要。

## Verification limits

子串检查不能证明推论得到支持。
“预计”改成“实际”仍可能带着真实引文。
真实语义质量需要另做模型实验和人工复核。
Skill 触发测试必须使用真实 Agent。
三个正例、一个近似反例和完整运行分别记录。
未执行的项目保持 `NOT_RUN`。
关键词匹配不能替代模型触发证据。

## Handoff to lesson 06

下一课只接收合法的 `validated` 报告。
它再次检查 `report_sha256`。
它冻结完整输入 JSON，包括指标和步骤。
因此基线和工作流结果是不同的输入产物。
本课结果没有操作键。
下一课根据运行身份定义操作键。
