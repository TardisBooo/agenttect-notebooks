"""Public behavior checks. Supply the directory containing workflow_lab."""

import argparse
import copy
import hashlib
import json
import os
import subprocess
import sys
import unittest
import uuid
from pathlib import Path

PARSER = argparse.ArgumentParser()
PARSER.add_argument("--project", type=Path, required=True)
PARSER.add_argument("--scratch", type=Path, default=Path.cwd() / "tmp/workflow-acceptance")
ARGS, REST = PARSER.parse_known_args()
PROJECT = ARGS.project.resolve()
FIXTURES = Path(__file__).resolve().parents[1] / "fixtures"


def digest(value):
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


class WorkflowAcceptance(unittest.TestCase):
    def setUp(self):
        self.root = ARGS.scratch.resolve() / uuid.uuid4().hex
        self.root.mkdir(parents=True)
        self.snapshot = json.loads((FIXTURES / "snapshot.json").read_text(encoding="utf-8"))
        self.task = {"kind": "compare", "paths": ["a.json", "b.json"]}

    def invoke(self, args):
        env = {**os.environ, "PYTHONPATH": str(PROJECT), "PYTHONIOENCODING": "utf-8"}
        proc = subprocess.run(
            [sys.executable, "-X", "utf8", "-m", "workflow_lab", *args],
            cwd=self.root,
            env=env,
            capture_output=True,
            text=True,
            encoding="utf-8",
            timeout=10,
        )
        self.assertNotIn("Traceback", proc.stderr)
        return proc.returncode, json.loads(proc.stdout)

    def run_case(self, command="run"):
        for name, obj in (("snapshot", self.snapshot), ("task", self.task)):
            (self.root / f"{name}.json").write_text(
                json.dumps(obj, ensure_ascii=False), encoding="utf-8"
            )
        return self.invoke(
            [
                command,
                "--snapshot",
                str(self.root / "snapshot.json"),
                "--task",
                str(self.root / "task.json"),
                "--adapter",
                "fixture",
                "--output",
                str(self.root / "result.json"),
            ]
        )

    def replace_document(self, path, value):
        item = next(f for f in self.snapshot["files"] if f["path"] == path)
        item["content"] = json.dumps(value, ensure_ascii=False, separators=(",", ":"))
        item["bytes"] = len(item["content"].encode("utf-8"))
        self.snapshot["total_bytes"] = sum(f["bytes"] for f in self.snapshot["files"])

    def assert_rejected(self, result, code):
        exit_code, output = result
        self.assertEqual(exit_code, 1)
        self.assertEqual(output["status"], "rejected")
        self.assertIn(code, output["errors"])
        self.assertIsNone(output["report"])
        self.assertIsNone(output["report_sha256"])
        self.assertEqual(output["steps"][-1]["status"], "skipped")

    def test_normal_comparison_and_hashes(self):
        exit_code, output = self.run_case()
        self.assertEqual(exit_code, 0)
        self.assertEqual(output["status"], "validated")
        self.assertEqual(output["schema"], "workflow-report/v1")
        self.assertEqual(output["adapter"], "fixture")
        self.assertEqual(output["report"]["summary"], "b.json minus a.json: 30 items (2025).")
        self.assertEqual(output["report_sha256"], digest(output["report"]))
        self.assertEqual(
            output["snapshot_sha256"],
            digest({"files": self.snapshot["files"], "total_bytes": self.snapshot["total_bytes"]}),
        )
        findings = output["report"]["findings"]
        self.assertEqual([f["path"] for f in findings], self.task["paths"])
        for finding, source in zip(findings, self.snapshot["files"], strict=True):
            self.assertIn(finding["evidence"], source["content"])
        self.assertEqual(
            json.loads((self.root / "result.json").read_text(encoding="utf-8")), output
        )

    def test_baseline_same_inputs_same_report(self):
        first = self.run_case()[1]
        second = self.run_case("baseline")[1]
        self.assertEqual(first["report"], second["report"])
        self.assertEqual(first["snapshot_sha256"], second["snapshot_sha256"])
        self.assertEqual((first["metrics"]["calls"], second["metrics"]["calls"]), (2, 1))

    def test_baseline_obeys_same_failure_criteria(self):
        self.task["faults"] = {"b.json": "missing_unit"}
        self.assert_rejected(self.run_case("baseline"), "MISSING_UNIT")

    def test_qa_reads_non_numeric_documents(self):
        self.task["kind"] = "qa"
        self.replace_document("a.json", "Only a note.")
        code, result = self.run_case()
        self.assertEqual(code, 0)
        self.assertEqual(result["route"], "qa")
        self.assertEqual(len(result["report"]["findings"]), 2)

    def test_unsupported_route_makes_no_calls(self):
        self.task["kind"] = "send_email"
        result = self.run_case()
        self.assert_rejected(result, "UNSUPPORTED_TASK")
        self.assertEqual(result[1]["metrics"]["calls"], 0)

    def test_unit_mismatch(self):
        self.replace_document("b.json", {"period": "2025", "unit": "USD", "value": 150})
        self.assert_rejected(self.run_case(), "UNIT_MISMATCH")

    def test_period_mismatch(self):
        self.replace_document("b.json", {"period": "2024", "unit": "items", "value": 150})
        self.assert_rejected(self.run_case(), "PERIOD_MISMATCH")

    def test_missing_unit(self):
        self.task["faults"] = {"b.json": "missing_unit"}
        self.assert_rejected(self.run_case(), "MISSING_UNIT")

    def test_missing_period(self):
        self.replace_document("b.json", {"unit": "items", "value": 150})
        self.assert_rejected(self.run_case(), "MISSING_PERIOD")

    def test_boolean_is_not_numeric_value(self):
        self.replace_document("b.json", {"period": "2025", "unit": "items", "value": True})
        self.assert_rejected(self.run_case(), "INVALID_VALUE")

    def test_numeric_overflow_saves_rejected_report(self):
        for command in ("run", "baseline"):
            for left, right in ((120, 10**400), (-10**308, 10**308), (-1e308, 1e308)):
                with self.subTest(command=command, left=left, right=right):
                    for path, value in (("a.json", left), ("b.json", right)):
                        self.replace_document(
                            path, {"period": "2025", "unit": "items", "value": value}
                        )
                    result = self.run_case(command)
                    self.assert_rejected(result, "INVALID_VALUE")
                    saved = json.loads((self.root / "result.json").read_text(encoding="utf-8"))
                    self.assertEqual(saved, result[1])
                    gate = next(step for step in saved["steps"] if step["id"] == "gate")
                    self.assertEqual(
                        (gate["status"], gate["error_code"]), ("failed", "INVALID_VALUE")
                    )

    def test_bad_extraction(self):
        self.task["faults"] = {"a.json": "bad_json"}
        self.assert_rejected(self.run_case(), "INVALID_EXTRACTION")

    def test_unsupported_evidence(self):
        self.task["faults"] = {"b.json": "unsupported_evidence"}
        self.assert_rejected(self.run_case(), "UNSUPPORTED_EVIDENCE")

    def test_fault_timeout(self):
        self.task["faults"] = {"b.json": "timeout"}
        self.assert_rejected(self.run_case(), "BRANCH_TIMEOUT")

    def test_real_delayed_branch_exceeds_collection_deadline(self):
        self.task.update(deadline_ms=10, delay_ms={"b.json": 100})
        self.assert_rejected(self.run_case(), "BRANCH_TIMEOUT")

    def test_completion_order_does_not_change_task_order(self):
        self.task["delay_ms"] = {"a.json": 50}
        result = self.run_case()[1]
        self.assertEqual([f["path"] for f in result["report"]["findings"]], self.task["paths"])
        self.task["paths"].reverse()
        result = self.run_case()[1]
        self.assertEqual(result["report"]["summary"], "a.json minus b.json: -30 items (2025).")

    def test_snapshot_byte_validation(self):
        self.snapshot["files"][0]["bytes"] = 1
        code, result = self.run_case()
        self.assertEqual((code, result["error_code"]), (2, "BYTE_MISMATCH"))

    def test_duplicate_snapshot_paths(self):
        self.snapshot["files"][1]["path"] = "a.json"
        self.assertEqual(self.run_case()[1]["error_code"], "DUPLICATE_PATH")

    def test_unsafe_paths(self):
        for path in ("../a.json", "/a.json", "C:/a.json", "dir\\a.json", "dir//a.json"):
            with self.subTest(path=path):
                self.snapshot["files"][0]["path"] = path
                self.assertEqual(self.run_case()[1]["error_code"], "INVALID_PATH")

    def test_missing_and_duplicate_task_paths(self):
        for paths in (["missing.json", "b.json"], ["a.json", "a.json"]):
            with self.subTest(paths=paths):
                self.task["paths"] = paths
                self.assertEqual(self.run_case()[1]["error_code"], "UNKNOWN_PATH")

    def test_unicode_counts_utf8_bytes(self):
        self.task["kind"] = "qa"
        self.replace_document("a.json", "中文资料")
        self.assertEqual(self.run_case()[0], 0)

    def test_verify_detects_tampering(self):
        result = self.run_case()[1]
        result["report"]["summary"] = "Altered"
        target = self.root / "tampered.json"
        target.write_text(json.dumps(result), encoding="utf-8")
        code, output = self.invoke(["verify", "--result", str(target)])
        self.assertEqual((code, output["error_code"]), (2, "REPORT_DIGEST_MISMATCH"))

    def test_verify_accepts_valid_rejection_without_claiming_success(self):
        self.task["kind"] = "unsupported"
        self.run_case()
        code, output = self.invoke(["verify", "--result", str(self.root / "result.json")])
        self.assertEqual(code, 0)
        self.assertEqual(output["status"], "rejected")
        self.assertEqual(output["scope"], "structure_and_digest_only")

    def test_verify_rejects_malformed_result_shapes(self):
        original = self.run_case()[1]
        variants = []
        for field, value in (
            ("steps", []),
            ("snapshot_sha256", "x" * 64),
            ("route", "unknown"),
            ("errors", [3]),
        ):
            variant = copy.deepcopy(original)
            variant[field] = value
            variants.append(variant)
        variant = copy.deepcopy(original)
        variant["steps"].append(variant["steps"][0])
        variants.append(variant)
        variant = copy.deepcopy(original)
        variant.pop("route")
        variants.append(variant)
        for index, variant in enumerate(variants):
            with self.subTest(index=index):
                target = self.root / "malformed.json"
                target.write_text(json.dumps(variant), encoding="utf-8")
                self.assertEqual(self.invoke(["verify", "--result", str(target)])[0], 2)

    def test_verify_requires_null_or_nonempty_step_error_code(self):
        successful = self.run_case()[1]
        self.task["kind"] = "unsupported"
        rejected = self.run_case()[1]
        for original, status, invalid_codes in (
            (successful, "passed", ("", False, 0, "INVALID_VALUE")),
            (rejected, "skipped", ("", False, 0, "INVALID_VALUE")),
            (rejected, "failed", (None, "", False, 0)),
        ):
            for error_code in invalid_codes:
                with self.subTest(status=status, error_code=error_code):
                    variant = copy.deepcopy(original)
                    step = next(s for s in variant["steps"] if s["status"] == status)
                    step["error_code"] = error_code
                    target = self.root / "invalid-step.json"
                    target.write_text(json.dumps(variant), encoding="utf-8")
                    code, output = self.invoke(["verify", "--result", str(target)])
                    self.assertEqual((code, output.get("error_code")), (2, "INVALID_RESULT"))

    def test_invalid_json_has_stable_error(self):
        target = self.root / "bad.json"
        target.write_text("{", encoding="utf-8")
        self.assertEqual(
            self.invoke(["verify", "--result", str(target)])[1]["error_code"], "INPUT_ERROR"
        )


if __name__ == "__main__":
    unittest.main(argv=[sys.argv[0], *REST])
