# 文件快照工作流实验

本实验把当前快照变成可检查的报告。
先按契约实现入口，再运行正常和失败情景。
学生包提供合成资料、公开测试和空实现目录。

## 准备运行环境

在 PowerShell 中进入解压后的学生目录。
当前目录应包含 `contract.md` 和 `fixtures`。
检查 Python 版本。

```powershell
python --version
```

使用 Python 3.11 或更新版本。
本实验只需标准库，不需要 API 密钥。
为本次证据创建目录。

```powershell
New-Item -ItemType Directory -Force evidence | Out-Null
$env:PYTHONPATH = (Resolve-Path implementation).Path
```

本终端通过 `PYTHONPATH` 查找你的实现。
新终端需要重新设置这个变量。

## 创建命令入口

先读 [公开契约](contract.md)。
在 `implementation` 下创建 `workflow_lab` 目录。
在该目录创建 `__init__.py` 和 `__main__.py`。
按契约实现三个命令。

```text
implementation/
  workflow_lab/
    __init__.py
    __main__.py
```

空目录目前不能运行这些命令。
此时出现模块不存在，表示实现尚未创建。
它不是模型调用失败。
本页不提供命令处理器或教师答案。

## 固定同一组资料

打开 `fixtures/snapshot.json`。
两份文档分别记录 120 和 150 items。
它们的期间均为 2025。
任务按 `a.json`、`b.json` 的顺序比较。
预期差值是第二份减第一份，即 30 items。

文件正文是 JSON 字符串。
修改正文时，也要更新 UTF-8 字节数和总数。
不要把字符数当作字节数。

## 运行基线与工作流

实现入口后，使用同一快照和任务运行。

```powershell
python -m workflow_lab baseline --snapshot fixtures/snapshot.json --task fixtures/task-compare.json --adapter fixture --output evidence/baseline.json
$LASTEXITCODE
python -m workflow_lab run --snapshot fixtures/snapshot.json --task fixtures/task-compare.json --adapter fixture --output evidence/result.json
$LASTEXITCODE
```

两次成功运行的退出码都应为 0。
两个报告的 `status` 都应为 `validated`。
报告应包含以下摘要。

```text
b.json minus a.json: 30 items (2025).
```

逐条检查 `findings` 的路径和证据。
证据必须出现在本次快照正文中。
检查 `steps` 是否保留完整步骤。
将结果填入 `templates/COMPARISON.md`。
调用数只统计逻辑适配器请求。
fixture 没有调用真实模型。

## 检查报告摘要

```powershell
python -m workflow_lab verify --result evidence/result.json
$LASTEXITCODE
```

成功应返回 `ok=true`。
`scope` 应为 `structure_and_digest_only`。
这个命令检查结构和报告摘要。
它不能重查原快照中的证据。
它也不能证明作者身份或原文真实性。

## 运行只读摘录与超时情景

```powershell
python -m workflow_lab run --snapshot fixtures/snapshot.json --task fixtures/task-qa.json --adapter fixture --output evidence/qa.json
$LASTEXITCODE
python -m workflow_lab run --snapshot fixtures/snapshot.json --task fixtures/task-timeout.json --adapter fixture --output evidence/timeout.json
$LASTEXITCODE
```

只读摘录应成功，退出码为 0。
超时情景应拒绝，退出码为 1。
超时结果的错误列表包含 `BRANCH_TIMEOUT`。
它的 `report` 为 `null`。
报告步骤应为 `skipped`。
这里使用显式故障注入，不测网络超时概率。

## 运行公开验收

```powershell
python tests/acceptance.py --project implementation --scratch evidence/acceptance -v
$LASTEXITCODE
```

公开套件通过新进程调用你的 CLI。
它包含正常比较、路由、坏输出和超时情景。
它还检查路径、字节数、报告篡改和顺序。
失败时先读第一处不符合契约的行为。
不要修改测试来跳过尚未实现的要求。
生成的输入和输出保留供复查。

## 把验证过程写成 Skill

先保存一次手工验证记录。
再根据 `templates/SKILL-PLAN.md` 编写 Skill。
确定性命令应保持可复现。
单位错误和摘要错误应进入不同判断分支。

用真实 Agent 运行触发测试。
填写 `templates/trigger-cases.json`。
保留三个正例和一个近似反例。
另填 `templates/SKILL-RUN.md`。
记录一次完整运行的命令和判断。
尚未运行的项目保持 `NOT_RUN`。
控制测试通过不代表 Skill 已触发或运行。
