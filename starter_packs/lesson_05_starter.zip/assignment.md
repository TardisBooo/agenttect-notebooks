# 第 5 课作业：受控修改 `a.txt` 的运行时拦截与确定性 Skill 编排

<div style="background: #151719; border: 1px solid #22c55e; border-radius: 8px; padding: 18px 24px; margin: 20px 0; color: #f1f5f9;">
  <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
    <h3 style="margin: 0; color: #4ade80; font-size: 18px;">🚀 Google Colab 实验云环境（支持直接打开与交互验证）</h3>
    <a href="https://colab.research.google.com/github/viewatom/agentTect/blob/main/notebooks/student/lessons/lesson_05_workflow_skills.ipynb" target="_blank" rel="noopener noreferrer">
      <img src="https://colab.research.google.com/assets/colab-badge.svg" alt="Open In Colab" style="height: 32px;" />
    </a>
  </div>
  <p style="margin: 0 0 10px 0; font-size: 14px; color: #94a3b8; line-height: 1.6;">
    <strong>Colab 使用说明</strong>：无需配置本地 Python 环境，点击上方按钮直接在 Colab 打开。按照 Cell 提示补全标有 <code># TODO</code> 的核心逻辑，顺次运行至最后一个单元格即可自动生成带 SHA-256 签名的 100 分验真回执！
  </p>
</div>

> **【作业任务简介】（420 字）**  
> 本作业旨在解决大模型面对文件“写操作”时的幻觉与失控问题，并掌握工业级复合工作流的确定性编排。  
> 
> 在本实验中，你将通过纯 Python 实现两大核心模块：  
> 1. **受控修改 `a.txt` 的运行时四层门禁**：为宿主程序实现对模型写操作的拦截内核。依次通过参数越界与越狱路径校验、前置基线快照备份、沙箱安全写入与 SHA-256 签名、以及宿主独立发起的测试回归。只要测试未过，宿主自动秒级回滚基线，杜绝模型虚报成功。  
> 2. **三层渐进式披露的 Skill 与确定性编排**：遵循 Stanford CS146S 标准，编写标准化 `SKILL.md` 契约，实现发现层（元数据）、激活层（加载契约）与执行层（沙箱运行）的解耦隔离，并用提示链串联起跨文档提取与无歧义路由。  
> 
> **验收方式**：在 Colab 或本地运行测试套件，必须通过全部 26 项严格用例，自动生成 100 分满分回执。

---

## 一、作业背景：为什么需要运行时拦截与确定性编排？

在第 3.5 课与第 4 课中，我们分别解决了 Agent 系统的单循环控制与规格驱动上下文。然而，当大模型面临真实世界的复杂生产任务时，两个致命缺陷会彻底击溃系统：
1. **写操作缺乏运行时强制管控**：如果直接把文件写权限交给模型，模型在长推理后极易发生幻觉，直接篡改非目标文件、删掉测试断言，甚至在未经测试验证的情况下就向用户谎称“已修复完成”；
2. **长任务认知过载与注意力稀释**：把多份复杂报表一次性塞入单次提示词，模型的注意力机制会发生稀释，微小的概率偏差会在复合推理中发生级联放大（$0.95^5 \approx 77.4\%$）。

现代工业级 Agent 框架（Claude Code、OpenAI Agents SDK、LangGraph）的共同共识是：**快照与校验沙箱由宿主强制掌控（三大所有权铁律），业务路径已知时优先使用确定性工作流包裹局部概率推理**。

---

## 二、作业 1：受控修改 `a.txt` 的运行时四层拦截与快照沙箱

### 1. 业务场景设定
当前工作区存在一个基线文件 `a.txt`，里面存放着核心业务配置：
```text
server_port=8080
max_connections=100
timeout_seconds=30
```
任务要求：将 `server_port` 从 `8080` 修改为 `8888`，并保持其余两行完全不变。

### 2. 运行时（Runtime）怎么知道如何介入检查？（核心架构拆解）
大模型在提议动作时，只能输出 JSON 动作意图（Tool Call），**没有任何直接操作底层操作系统文件的物理权限**。运行时依据以下流程强制介入：

```mermaid
flowchart TD
    A["模型提议 Tool Call: edit_file(path='a.txt', patch=...)"] --> B{"Runtime 意图分类<br/>是读还是写？"}
    B -- "只读操作 (read/list)" --> C["直接读取，无需前置快照"]
    B -- "写操作 (write/edit/delete)" --> D["【强制介入 1】基线快照锁定<br/>自动读取 a.txt 内存镜像并计算 SHA-256"]
    D --> E["【强制介入 2】预写日志 (WAL) 与 Diff 预览<br/>生成结构化 Search/Replace 差异补丁"]
    E --> F["【强制介入 3】隔离沙箱 Dry-Run 校验<br/>语法检查 · 契约门禁 · 运行独立 pytest"]
    F -- "校验失败" --> G["【强制介入 4A】原子丢弃与回滚<br/>恢复基线快照，仅将裁剪后的错误摘要返回模型"]
    F -- "校验全部通过" --> H["【强制介入 4B】原子落盘生效<br/>写入磁盘并输出带有 SHA-256 的完成收据"]
```

### 3. 三大所有权铁律（必须在代码中体现）
- **铁律 1：快照归宿主**——快照在模型发起写操作之前由运行时自动冻结，绝对不依赖模型“主动调用备份工具”，不占用模型提示词 Token；
- **铁律 2：校验归代码**——校验规则（测试用例、Linter、契约）由宿主以静态代码固化，什么时候测、怎么测由运行时说了算，模型无权决定“跳过测试”；
- **铁律 3：沙箱物理隔离**——运行时的只读测试沙箱与模型的生成上下文严格绝缘，防止模型偷偷修改测试断言欺骗系统。

### 4. 作业 1 必交成果
在 `workflow-v1/student/implementation/` 中完成 `file_runtime_guard.py`，包含：
- `freeze_snapshot(file_path)`：返回基线内容的 SHA-256；
- `dry_run_patch(file_path, old_str, new_str)`：在内存沙箱中模拟打补丁；
- `validate_constraints(patched_content)`：四层门禁检查（端口范围 8000~8999、非空校验、格式校验）；
- `atomic_commit_or_rollback(...)`：根据校验结果原子落盘或彻底回滚。

---

## 三、作业 2：基于 `SKILL.md` 渐进式披露的固定工作流引擎

### 1. 业务场景设定
对两份财务快照文档（`fixtures/snapshot.json` 中的 `a.json` 与 `b.json`）执行严格的跨文档财务指标提取、单位对齐与差值计算任务，并编写独立的 `verify-workflow-report` 技能包。

### 2. 三大拓扑编原语实现
- **提示链（Prompt Chaining）**：按因果依赖顺序拆解为：`提取 a` $\to$ `提取 b` $\to$ `语义门禁校验` $\to$ `确定性差值计算` $\to$ `生成报告`；
- **显式路由（Router）**：
  - `kind="qa"`：走单文档只读问答流；
  - `kind="compare"`：走双文档数值比对流；
  - `未知任务`：零调用（`calls=0`）直接拒识退出（Fail-Closed）；
- **并行编排（Parallelization）**：
  - 双文档提取采用多线程并发执行（Fan-Out）；
  - 汇聚点（Fan-In）按输入文件路径列表严格保序合并，确保乱序并发下的输出完全确定。

### 3. 四层语义门禁（Semantic Gate）
在计算指标差值前，强制介入四层校验：
1. **第 1 层：语法格式校验**（提取的 JSON 字段完整且类型匹配）；
2. **第 2 层：原文子串严格对齐**（提取的 `evidence` 必须是快照正文的精确子串，严禁伪造）；
3. **第 3 层：业务语义口径统一**（报告期 `period` 必须一致，计量单位 `unit` 必须一致，不一致则立即抛出 `PERIOD_MISMATCH` 或 `UNIT_MISMATCH` 熔断）；
4. **第 4 层：故障熔断与三态轨迹**（超时抛 `BRANCH_TIMEOUT`，失败步骤后的后续节点自动标为 `skipped`）。

### 4. 验证型技能封装（`SKILL.md`）
遵循斯坦福 CS146S 第一铁律（先手工验证再写技能）：
- 编写 `skills/verify-workflow-report/SKILL.md`，明确触发条件、排除边界与离线验证 CLI 命令；
- 在 `evidence/trigger-cases.json` 记录 3 个触发正例与 1 个近似反例；
- 运行验证技能，生成真实运行记录 `evidence/SKILL-RUN.md`。

---

## 四、本地运行与 100 分验收命令

本作业自带全套离线自动化测试套件，在根目录下执行：

```powershell
# 1. 运行学生作业完整验收测试（26 项断言）
uv run python course/lessons/05-multi-agent-a2a/workflow-v1/student/tests/acceptance.py --project course/lessons/05-multi-agent-a2a/workflow-v1/instructor/reference -v

# 2. 运行教师端自动化检验脚本，生成最终验收回执
uv run python course/lessons/05-multi-agent-a2a/workflow-v1/instructor/verify.py --output tmp/workflow_verification_report
```

验收合格回执必须满足：
```json
{
  "schema": "lesson05-verification/v1",
  "status": "PASS",
  "tests_run": 26,
  "failed": 0,
  "passed": 26
}
```

---

## 五、评分细则（Rubric - 满分 100 分）

| 维度 | 分值 | 评分标准 |
| :--- | :--- | :--- |
| **运行时写拦截与快照沙箱** | 20 分 | 正确实现快照冻结、内存 Diff 校验、四层门禁检查与原子提交/回滚机制，基线文件无脏写入。 |
| **提示链与显式路由** | 20 分 | 阶段强类型交接无信息丢失；未知任务严格零调用拒识（`calls=0`, 退出码 1）。 |
| **可控并行与保序合并** | 20 分 | 多线程并发提取正常；汇聚结果严格按输入路径保序，乱序到达不影响最终报告哈希。 |
| **四层语义门禁与三态轨迹** | 20 分 | 精确子串匹配、口径不一致熔断、超时熔断处理完善，步骤轨迹正确记录 `passed/failed/skipped`。 |
| **验证 Skill 与三正一反评测** | 20 分 | `SKILL.md` 边界清晰；`trigger-cases.json` 包含 3 正 1 反评测；`SKILL-RUN.md` 包含完整命令与诊断。 |
